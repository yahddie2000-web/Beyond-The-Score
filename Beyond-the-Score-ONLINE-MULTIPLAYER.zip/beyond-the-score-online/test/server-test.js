'use strict';
const assert=require('node:assert/strict');
const BASE='http://127.0.0.1:'+(process.env.PORT||3000)+'/api/';
async function api(method,endpoint,payload){const r=await fetch(BASE+endpoint,{method,headers:payload?{'Content-Type':'application/json'}:{},body:payload?JSON.stringify(payload):undefined});const x=await r.json();if(!r.ok)throw new Error(endpoint+': '+r.status+' '+JSON.stringify(x));return x;}
(async()=>{
 const catalog=await api('GET','catalog');assert.equal(catalog.total,102);assert.equal(catalog.backgrounds.length,12);
 const a=await api('POST','create',{name:'Test A'}),b=await api('POST','join',{code:a.code,name:'Test B'});
 await api('POST','profile',{code:a.code,token:b.token,name:'Test B',background:'biasedElite',home:'strict',priority:'Curiosity'});
 await api('POST','start',{code:a.code,token:a.token});let state=await api('GET',`state?code=${a.code}&token=${a.token}`);
 assert.equal(state.game.current,0);assert.equal(state.seats[1].background,'biasedElite');
 const invalid=await fetch(BASE+'action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:a.code,token:b.token,type:'choose',index:0})});assert.equal(invalid.status,403);
 let commands=0;
 for(;;){state=await api('GET',`state?code=${a.code}&token=${a.token}`);if(state.stage==='finish')break;const p=state.game.current,token=p===0?a.token:b.token;if(state.game.phase==='spin')await api('POST','action',{code:a.code,token,type:'spin'});else if(state.game.phase==='decision'){const option=state.chapter.options.find(x=>x.enabled);assert(option);await api('POST','action',{code:a.code,token,type:'choose',index:option.index});}else if(state.game.phase==='result')await api('POST','action',{code:a.code,token,type:'next'});else throw new Error(state.game.phase);assert(++commands<1000);}
 assert.equal(state.game.round,102);assert.equal(state.game.players.length,2);console.log(`PASS: ${commands} two-player actions, 102 chapters, permission enforcement, multiple starting environments.`);
 for(const preset of ['party','business']){const room=await api('POST','create',{name:'Demo Test'});await api('POST','demo',{code:room.code,token:room.token,preset});const state=await api('GET',`state?code=${room.code}&token=${room.token}`);assert.equal(state.chapter.title,preset==='party'?'A college party':'Launch a specific business');console.log('PASS: demonstration shortcut',preset);}
})().catch(e=>{console.error(e);process.exitCode=1});
