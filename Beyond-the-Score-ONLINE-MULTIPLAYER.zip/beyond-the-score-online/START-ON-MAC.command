#!/bin/zsh
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 20 or newer is required to run the online server on your Mac."
  echo "Install Node.js from https://nodejs.org/ or deploy this project on Render instead."
  echo "After installing Node.js, double-click this file again."
  read '?Press Return to close: '
  exit 1
fi
( sleep 2; open "http://localhost:3000" ) &
echo "Starting Beyond the Score. Keep this window open while playing locally."
echo "For friends on different networks, deploy this folder to Render using README.md."
node server.js
