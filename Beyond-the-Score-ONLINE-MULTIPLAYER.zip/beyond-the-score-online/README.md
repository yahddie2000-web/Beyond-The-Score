# BEYOND THE SCORE — ONLINE CLASSROOM EDITION

A shared, real-time board game about intelligence, experience, choice, social context, and consequence. This is an interactive prototype for an intelligence colloquium, not an IQ test or a scientific predictor of life outcomes.

**This edition requires a server.** It cannot connect separate computers if you simply double-click `public/index.html` or the earlier standalone `.html` game. It includes a Node.js server and browser frontend. Everything needed to run the code is in this folder; no third-party packages, API keys, or paid AI services are required.

## Features

- Up to **four active players** in one room, and additional spectators (up to 25).
- Host creates a six-character code; players join by link or code from other computers.
- **Server-controlled turns, decisions, random rolls and delayed consequences**. One consistent game state, rather than four independently running copies.
- 102 life chapters, 12 starting neighborhoods, four home circumstances, sports, college, trades, career pathways, entrepreneurship, relationships, and emotional decisions, all derived from the latest Expanded Life Edition.
- Animated life board with moving player indicators, visible deliberation highlights, spin wheel, choice reveal animations and live state updates via Server-Sent Events (SSE).
- Optional public self-reported feeling *after* a decision; feelings are not treated as objective intelligence measures.
- Host **presentation shortcuts** to age 19's college party or the business-launch chapter. Earlier turns in these shortcuts are simulated, and the interface labels them as such.
- Save/download life histories as a readable text file. Automatic server room snapshots are written to `data/rooms.json` on a running server.

## Easiest way to make it public (GitHub + Render)

1. Extract this ZIP onto your computer.
2. Create a **new GitHub repository**. Upload the contents of this `beyond-the-score-online` folder, preserving the `public` and `test` folders. Avoid uploading the `data/rooms.json` snapshot if you've played locally. You can use GitHub Desktop instead of the browser upload screen.
3. At https://dashboard.render.com, sign in and choose **New → Web Service**. Connect your new GitHub repository.
4. Set Language / Runtime to **Node**, Build Command to `npm install`, Start Command to `npm start`. If available, choose the **Free** plan. The included `render.yaml` can also be used for a Render Blueprint.
5. Deploy. Render will assign a public HTTPS address resembling `https://your-site.onrender.com`. **That address is the shared online game.** Open it on one computer, click **Create room**, then click **Copy invitation link** and share with others.
6. In the lobby, everyone picks their own neighborhood, home environment, and personal priority. The host starts the game. Each computer sees the same board and decisions.

**Important limitations of free hosting:** Render's free web services can sleep after 15 minutes without inbound traffic, and their local files are ephemeral across restarts/deployments. The game makes regular requests while a room is open, but a restart can still erase ongoing rooms. For a high-stakes or multi-day session, add persistent database storage or use a paid persistent host. Test the deployed link on two computers before class.

Official references: [Deploy Node apps on Render](https://render.com/docs/deploy-node-express-app), [Free service limitations](https://render.com/docs/free).

## Running locally

Requires Node.js 20 or newer.

```bash
npm start
```

Then open **http://localhost:3000**. On a Mac with Node.js installed, you can also double-click `START-ON-MAC.command` (depending on macOS security permissions). If you want to connect from another device on the same Wi-Fi network *without deploying*, visit `http://YOUR-COMPUTER-LAN-IP:3000` from that device (if your computer's firewall allows the connection). For connections across the wider Internet, deploy to a hosting service.

No `npm install` is needed to run locally because the game has no external runtime dependencies. You may run it anyway if your hosting service requires a build command.

## Playing and demonstrating

The host creates a room and shares the URL. Each player chooses their own background and clicks **Save my background**. The host chooses **Start journey**, **Jump to college party** or **Jump to starting a business**.

The active player's options are clickable on their computer. Everyone else sees the same scenario, a live highlight of the option they are considering, and the revealed decision plus chance result. When testing two seats on just one computer, open the second seat in a separate Chrome profile or private browsing session (two ordinary tabs share the same browser session token). The active player can optionally share a feeling, then advance to the next player. Spectators cannot submit choices. The host may advance the game after a choice if a player walks away.

All dollar amounts, probabilities, and simplified psychological indicators are fictional game mechanics. The game's comparisons are philosophical prompts, not validated empirical claims.

## Research connections

The game is adapted from the user's colloquium research and prior prototype pitch. It is explicitly interested in the limitations of reducing a person to one visible numerical outcome.

- **U.S. Office of Personnel Management, “Cognitive Ability Tests”** — Some reasoning and learning skills can be meaningfully assessed, but tests do not measure an entire life.
- **Michael Tye, “Qualia” (Stanford Encyclopedia of Philosophy)** — Observed behavior does not transparently reveal the subjective character of an experience.
- **David Chalmers, “Consciousness, iPhones and Philosophical Zombies”** — Consciousness versus outward behavior is a philosophical question, not a score on a game board.
- **Nummenmaa et al., “Maps of Subjective Feelings” (2018)** — Studying self-reported feelings offers a distinct kind of evidence from income, education or prestige.
- **Umut Baysan, “Mad Qualia” (2019)** — The causal role of subjective experience is debated, so the game does not claim that feelings automatically determine behavior.

The game's choice probabilities and resource adjustments were authored for play; they are not derived as quantitative effect estimates from those works.

## Security and privacy

This is a **classroom prototype**, not a public commercial platform. Rooms are identified with short codes and anonymous browser session tokens. Anyone with the room link can spectate once a game has started. Use nicknames, not personal identifiers. Other room participants can see the decisions, voluntary feelings and life histories that are generated inside the game. No gambling and no advertising.

## Files

- `server.js`: HTTP/SSE room server, authoritative turns, saved room state.
- `engine-core.js`: original Expanded Edition's 102-chapter logic, extracted for running on the server. Random events, careers and delayed consequences retain their original logic.
- `public/index.html`, `public/style.css`, `public/app.js`: animated, responsive online interface.
- `offline-original.html`: standalone previous edition, supplied as a backup; it is not itself multiplayer.
- `test/front-test.js`: frontend template smoke checks (Node).
- `render.yaml`: optional Render configuration.

## Known limitations / further upgrades

- No chat, login or moderation tools. The game is designed for invited classroom groups.
- Choices are sequential; a player who is away can stall a turn. The host may advance **after** choices are made, but cannot impersonate an absent player's actual decision.
- Each room uses memory plus a local JSON snapshot; a free cloud restart can lose that snapshot. For persistent games, attach a supported database.
- There are numerous combinations of scenarios, choices and rolls, not thousands of separately authored end narratives.
- The game is an original digital board experience, not an official licensed edition of *The Game of Life*.
