/* Derived from Beyond the Score Expanded Life Edition. Shared by same-room online multiplayer. */
const app=document.getElementById('app');
const E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const usd=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(Number(n)||0);
const clamp=(n,min=0,max=10)=>Math.max(min,Math.min(max,n));
const rng=(n)=>Math.floor(Math.random()*n);
const SAVE_KEY='beyond-the-score-version-6-game';
const OLD_SAVE_KEY='beyond-the-score-version-5-game';
const priorities=['Security','Relationships','Purpose','Freedom','Curiosity'];
const backgrounds=[
{id:'gated',name:'Affluent gated suburb',desc:'Access to tutoring, reliable transport and powerful networks.',but:'High status pressure and limited contact with different experiences.',plus:'Specialized programs and referrals',minus:'Competition, expectations and social isolation',cash:10500,energy:5,bonds:4,options:8,friction:1,pressure:3},
{id:'mutual',name:'Working-class mutual-aid neighborhood',desc:'Neighbors exchange rides, childcare and practical advice.',but:'Little emergency cash; paid activities and time off can be hard to afford.',plus:'Trust and community support',minus:'Tight savings and extra household duties',cash:1250,energy:6,bonds:8,options:5,friction:2,pressure:2},
{id:'industrial',name:'Industrial town in transition',desc:'Family trades, apprenticeships and practical mentorship are visible.',but:'Local industries are unstable and specialized programs are limited.',plus:'Hands-on skills and mentors',minus:'Employment uncertainty',cash:1900,energy:6,bonds:7,options:4,friction:2,pressure:2},
{id:'metro',name:'High-cost multicultural city district',desc:'Wide cultural life, transit, libraries and many kinds of people.',but:'High rents, crowding and uneven access to selective programs.',plus:'Diverse networks and cultural opportunities',minus:'Expensive living and unequal access',cash:3250,energy:5,bonds:6,options:7,friction:3,pressure:2},
{id:'rural',name:'Remote rural community',desc:'Neighbors know one another and outdoor activities are accessible.',but:'Transport to specialized schools, hospitals and clubs is difficult.',plus:'Strong local ties and autonomy',minus:'Long travel and fewer institutions',cash:2200,energy:7,bonds:7,options:3,friction:1,pressure:2},
{id:'rental',name:'Housing-insecure rental neighborhood',desc:'Residents share practical knowledge about navigating change.',but:'Unpredictable moves and repairs disrupt schedules and savings.',plus:'Adaptability and neighbor cooperation',minus:'Housing instability and interrupted routines',cash:420,energy:4,bonds:7,options:4,friction:2,pressure:3},
{id:'prep',name:'Prestigious competitive school district',desc:'Advanced classes, clubs and counselors are available.',but:'Constant comparison and academic pressure can undermine wellbeing.',plus:'Academic infrastructure',minus:'High pressure and social ranking',cash:7200,energy:4,bonds:4,options:9,friction:1,pressure:4},
{id:'newcomer',name:'Newcomer and immigrant-serving district',desc:'Mutual-aid networks, multilingual neighbors and community organizations.',but:'Families may face complex paperwork or unfamiliar institutions.',plus:'Cultural knowledge and mutual aid',minus:'Administrative and language-access barriers',cash:950,energy:6,bonds:8,options:5,friction:3,pressure:2},
{id:'civic',name:'Politically connected district',desc:'Local leaders can open doors through introductions and favors.',but:'Favoritism and ethical pressure make some opportunities conditional.',plus:'Access to influential contacts',minus:'Pressure to tolerate unfair practices',cash:5800,energy:5,bonds:5,options:7,friction:3,pressure:3},
{id:'policed',name:'Over-surveilled urban neighborhood',desc:'Residents organize youth programs and strong local support networks.',but:'Institutional suspicion and enforcement can create extra barriers.',plus:'Community organizers and solidarity',minus:'Surveillance and unfair institutional barriers',cash:1600,energy:5,bonds:8,options:5,friction:4,pressure:2},
{id:'collegeTown',name:'Mixed-income university neighborhood',desc:'Public lectures, libraries, campus jobs and research exposure.',but:'Rising housing costs and academic gatekeeping threaten access.',plus:'Nearby education and research',minus:'Displacement and gatekeeping',cash:3900,energy:6,bonds:6,options:7,friction:2,pressure:3},
{id:'biasedElite',name:'Resource-rich but exclusionary community',desc:'Exceptional facilities, sports clubs and professional connections.',but:'Prejudice and status hierarchies can restrict belonging and opportunity.',plus:'Strong facilities and connections',minus:'Prejudice, exclusion and peer pressure',cash:8350,energy:5,bonds:3,options:8,friction:4,pressure:3}
];
const homes=[
{id:'warm',name:'Supportive, busy household',plus:'You have people who encourage you.',minus:'Work and care duties reduce free time.',energy:0,bonds:1,options:0,cash:0,pressure:1},
{id:'strict',name:'Structured, high-expectation home',plus:'Clear routines and academic encouragement.',minus:'Less freedom to explore or fail.',energy:-1,bonds:0,options:1,cash:0,pressure:2},
{id:'independent',name:'Independent, flexible home',plus:'Room to experiment and make decisions.',minus:'Less regular guidance and follow-through.',energy:1,bonds:-1,options:0,cash:0,pressure:0},
{id:'changing',name:'Changing caregiving arrangements',plus:'You learn from different adults and perspectives.',minus:'Unstable schedules create emotional and practical demands.',energy:-1,bonds:1,options:0,cash:0,pressure:2}
];
const sportNames=['Basketball','Soccer','Track & field','Football','Swimming'];
const majorNames={psych:'Psychology',engineering:'Engineering & computing',business:'Business & economics',education:'Education',science:'Health & natural sciences',arts:'Arts & media',prelaw:'Law / public policy foundation',exercise:'Exercise science / sport management'};
const tradeNames={electric:'Electrical apprenticeship',mechanic:'Automotive technology',medical:'Clinical technician',it:'IT support & networks',culinary:'Culinary arts'};
const workNames={service:'Customer service & operations',logistics:'Warehouse & logistics',community:'Youth & community work',sales:'Sales apprenticeship',assistant:'Sports program assistant'};
const careerInfo={
trainer:{name:'Athletic trainer / coach',pay:3600,skill:'sport'},athlete:{name:'Professional athlete',pay:16200,skill:'sport'},
psychResearch:{name:'Psychology research assistant',pay:3150,skill:'academics'},therapist:{name:'Counseling / therapy track',pay:4250,skill:'care'},
software:{name:'Software developer',pay:5300,skill:'tech'},engineer:{name:'Engineer',pay:5350,skill:'tech'},
analyst:{name:'Business analyst',pay:4750,skill:'business'},founder:{name:'Small-business owner',pay:0,skill:'business'},
teacher:{name:'Teacher',pay:3850,skill:'academics'},scientist:{name:'Lab or research technician',pay:3550,skill:'academics'},
health:{name:'Healthcare support specialist',pay:3900,skill:'care'},artist:{name:'Designer / creative professional',pay:3300,skill:'art'},
policy:{name:'Legal / policy assistant',pay:3850,skill:'academics'},lawyer:{name:'Lawyer (after additional study)',pay:6300,skill:'academics'},
electric:{name:'Electrician',pay:4400,skill:'craft'},mechanic:{name:'Automotive technician',pay:4050,skill:'craft'},
medical:{name:'Clinical technician',pay:4000,skill:'care'},it:{name:'IT support specialist',pay:4100,skill:'tech'},
culinary:{name:'Chef / food service professional',pay:3400,skill:'craft'},service:{name:'Customer service / operations',pay:3300,skill:'business'},
logistics:{name:'Logistics coordinator',pay:3950,skill:'business'},community:{name:'Community program worker',pay:3250,skill:'care'},
sales:{name:'Sales associate',pay:3750,skill:'business'},assistant:{name:'Athletics program coordinator',pay:3550,skill:'sport'},
freelance:{name:'Independent contractor',pay:3350,skill:'business'}
};
const S=(label,desc,delta,outcome,more={})=>({label,desc,delta,outcome,...more});
const M=(age,stage,title,text,choices,type='everyday',kind='general')=>({age,stage,title,text,choices,type,kind});
const flag=(p,key)=>!!p.flags[key];
const effect=(delta={})=>delta;
let prefs=[{name:'Player 1',background:'mutual',home:'warm',priority:'Purpose'}];
let game={screen:'setup',players:[],round:0,current:0,phase:'decision',arrivals:[],last:null,turnNote:'',chance:null};
let saveSupported=true;
function chooseSport(name){return {sport:name,athletics:true};}
function courseCards(p){
const type=p.route;
if(type==='college')return [
S('Psychology', 'Study learning, behavior and experience; extra credentials may be necessary.',{skills:{academics:1,care:1},energy:-1,cash:-800},'You pursue psychology, but a degree is not automatically a therapy license.',{set:{major:'psych'}}),
S('Engineering & computing','Technical work opens career options but demands long courses.',{skills:{tech:2},energy:-2,cash:-1100},'You pursue technical education while managing a heavy workload.',{set:{major:'engineering'}}),
S('Business & economics','Learn organizations and finance, though networking is unequal.',{skills:{business:2},energy:-1,cash:-600},'You start understanding markets and organizational decisions.',{set:{major:'business'}}),
S('Education','Work toward teaching; serving others may limit income.',{skills:{academics:1,care:2},energy:-1,cash:-500},'You pursue teaching and learn how access changes students’ opportunities.',{set:{major:'education'}}),
S('Health & natural sciences','Study scientific systems; some careers require more training.',{skills:{academics:2,care:1},energy:-2,cash:-900},'You start research and practical training.',{set:{major:'science'}}),
S('Arts & media','Build a portfolio in a field with uncertain income.',{skills:{art:2},energy:-1,cash:-550},'Creative work becomes part of your education.',{set:{major:'arts'}}),
S('Law / public policy','Learn institutions; a law degree would still be separate.',{skills:{academics:2,business:1},energy:-2,cash:-750},'You study the people and institutions that shape opportunity.',{set:{major:'prelaw'}}),
S('Exercise science / sport management','Connect athletics to science and work beyond competition.',{skills:{sport:1,care:1,business:1},energy:-1,cash:-650},'You prepare for sport-related careers without relying on becoming professional.',{set:{major:'exercise'}})
];
if(type==='trade')return Object.entries(tradeNames).map(([id,name])=>S(name,`Practical training builds employable skills, but materials and schedules cost time.`,{cash:-850,energy:-1,skills:{[id==='electric'||id==='mechanic'||id==='culinary'?'craft':id==='it'?'tech':'care']:2}},`You enroll in ${name.toLowerCase()} training.`,{set:{program:id}}));
if(type==='work')return Object.entries(workNames).map(([id,name])=>S(name,'Begin earning now, but advancement might require more training.',{cash:1100,energy:-2,skills:{[id==='logistics'||id==='sales'||id==='service'?'business':id==='assistant'?'sport':'care']:1}},`You begin paid work in ${name.toLowerCase()}.`,{set:{program:id}}));
return [S('Work and build savings','Earn while learning daily job skills.',{cash:2100,energy:-2,skills:{business:1}},'A gap year turns into useful work experience.',{set:{program:'service'}}),S('Community-service placement','Learn from a new setting, but accept fewer paid hours.',{cash:-500,bonds:2,energy:-1,skills:{care:1}},'You expand your network and perspective.',{set:{program:'community'}}),S('Sport training year','Train and try to improve your odds without guaranteed offers.',{cash:-1350,energy:-2,skills:{sport:2}},'You dedicate time to competition and preparation.',{when:p=>p.sport,lock:'Choose a sport earlier.',set:{program:'assistant'}}),S('Explore courses and part-time work','Pay for some classes while working on a plan.',{cash:-850,options:2,energy:-1,skills:{academics:1}},'You stay flexible, but uncertainty has a cost.',{set:{program:'service'}})];
}
function careerOptions(p){
let arr=[];
if(p.flags.pro){arr.push(S('Continue your professional '+p.sport.toLowerCase()+' contract','Higher but unstable sports income; physical demands and contract risk remain.',{cash:3100,energy:-3,skills:{sport:1}},'You keep the developmental contract for now.',{set:{career:'athlete'}}));}

if(p.route==='college'){
 const byMajor={psych:[['psychResearch','Psychology research assistant'],['community','Community program worker']],engineering:[['software','Software developer'],['engineer','Engineer']],business:[['analyst','Business analyst'],['sales','Sales associate']],education:[['teacher','Teacher'],['community','Community program worker']],science:[['scientist','Lab/research technician'],['health','Healthcare support specialist']],arts:[['artist','Designer / creative professional'],['freelance','Independent creative contractor']],prelaw:[['policy','Legal / policy assistant'],['community','Community program worker']],exercise:[['trainer','Athletic coach / trainer'],['assistant','Athletics program coordinator']]};
 for(const [id,name] of (byMajor[p.major]||byMajor.psych))arr.push(S(name,'Specialized entry work has income potential, with time and performance demands.',{cash:1200,energy:-1,options:1,skills:{[careerInfo[id].skill]:1}},`You enter work as a ${careerInfo[id].name.toLowerCase()}.`,{set:{career:id}}));
} else {
 let id=p.program||'service';if(!careerInfo[id])id='service';
 arr.push(S(careerInfo[id].name,'Use the experience you already developed; industry conditions still matter.',{cash:1100,energy:-1,options:1},`You begin a more established role in ${careerInfo[id].name.toLowerCase()}.`,{set:{career:id}}));
 if(id!=='service')arr.push(S('Customer service / operations','Find a transferable job while preserving flexibility.',{cash:900,energy:-1,skills:{business:1}},'You change fields using practical skills.',{set:{career:'service'}}));
 arr.push(S('Independent contracting','Build clients and control your schedule, but face variable income.',{cash:400,energy:-2,options:2,skills:{business:1}},'You begin independent work without guaranteed steady clients.',{set:{career:'freelance'}}));
}
arr.push(S('Community youth program worker','Lower financial upside, but strong social purpose.',{cash:750,bonds:2,energy:-1,skills:{care:1}},'You build a career supporting younger people.',{set:{career:'community'}}));
return arr;
}
function sportCollegeChoices(p){
const arr=[];
if(p.sport){
  arr.push(S(`Try out for college ${p.sport.toLowerCase()}`,'Compete for a roster spot; a scholarship is possible, never automatic.',{energy:-2,skills:{sport:1},cash:-350},'You complete a college athletics evaluation. The result depends on preparation, access and luck.',{special:'collegeAthletics'}));
  arr.push(S('Play in a local club instead','Keep competing while avoiding a varsity schedule.',{energy:-1,bonds:1,skills:{sport:1},cash:-250},'You stay involved in the sport outside varsity competition.',{set:{clubSport:true}}));
}
arr.push(S('Prioritize academic / vocational opportunities','Put more time into study or trade-specific training.',{energy:-1,options:2,skills:{academics:1}},'You build a different set of options while leaving sports as an optional interest.'));
arr.push(S('Work to cover costs','Earn income, but sacrifice some training and study time.',{cash:1200,energy:-2,options:-1},'You gain cash and experience, but your schedule becomes less flexible.'));
return arr;
}
function proOptions(p){
const arr=[];
if(p.sport&&p.skills.sport>=3){
arr.push(S(`Pursue professional ${p.sport.toLowerCase()} tryouts`,'Rare, high-risk route. Travel and time cost money; a contract is not guaranteed.',{cash:-1800,energy:-2,skills:{sport:1}},'Your performance is evaluated at a professional or developmental level.',{special:'proTryout',set:{attemptedPro:true}}));
arr.push(S('Compete in semi-professional / club sport','Keep competing while earning elsewhere.',{cash:-500,energy:-1,skills:{sport:1},bonds:1},'You remain an athlete without relying entirely on a professional contract.',{set:{semiPro:true}}));
}
arr.push(S('Build a career linked to sport','Explore coaching, physical training or event operations.',{skills:{sport:1,business:1},options:1,energy:-1},'Sport may shape your career even without professional competition.',{set:{sportCareerInterest:true}}));
arr.push(S('Invest in a different direction','Develop education or work skills outside sport.',{skills:{academics:1},options:2,energy:-1},'Your past sports experience can still matter without defining your occupation.'));
return arr;
}
const scenes=[
M(5,'Childhood','Your first classroom',p=>`Your household is in a ${p.background.name.toLowerCase()}. A new school year begins, but families do not start with equal time or resources.`,[
S('Ask for help when you need it','A teacher can guide you, but speaking up feels uncomfortable.',{options:1,bonds:1,energy:-1,skills:{academics:1}},'A teacher remembers that you asked questions.',{later:{offset:4,delta:{options:1},text:'That teacher recommends you for an activity.'}}),
S('Observe and try things privately','Build patience and independence, but form connections more slowly.',{energy:1,skills:{academics:1},bonds:-1},'You learn by watching before joining.'),
S('Find a friend immediately','You build social support, but less time goes into classwork.',{bonds:2,skills:{academics:-1}},'You have someone to share the first week with.')]),
M(6,'Childhood','The playground disagreement','Two classmates disagree about the rules of a game. It would be easier to go with the loudest person.',[
S('Listen to both sides','Spend time helping everyone reach a compromise.',{bonds:2,energy:-1,skills:{care:1}},'You help people feel heard, but lose some playtime.'),
S('Choose a side','You gain one friend’s approval and risk another relationship.',{bonds:1,options:-1},'A quick decision ends the argument without resolving it.'),
S('Play by yourself today','Avoid conflict but miss a chance to practice cooperation.',{energy:2,bonds:-1},'You enjoy calm time alone.')]),
M(7,'Childhood','What catches your attention?','An adult asks what you want to explore after school. You can try something new, but time and equipment are limited.',[
S('A team sport','Join a low-cost introductory sport program; practice consumes energy.',{cash:-130,skills:{sport:1},energy:-1,bonds:1},'You find out what practice with a team is like.',{set:{interest:'sport',playedSport:true}}),
S('Drawing, music or dance','Build creative skills; equipment or classes cost money.',{cash:-120,skills:{art:2},energy:-1},'You start making things people can see and share.',{set:{interest:'arts'}}),
S('Science / computers','Explore puzzles and equipment; some tools are costly.',{cash:-100,skills:{tech:1,academics:1},energy:-1},'You begin working through systems.',{set:{interest:'science'}}),
S('Help with a community program','Develop relationships, though you have less unstructured play.',{bonds:2,skills:{care:1},energy:-1},'You learn by helping other people.',{set:{interest:'service'}})],'everyday','interests'),
M(8,'Elementary school','The activity you can actually attend',p=>`There is a new afterschool program. Getting there costs ${usd(230)} for transport and supplies. Your household support buffer is ${usd(p.cash)}.`,[
S('Pay for the program','Build a skill and meet mentors; money and time are limited.',{cash:-230,options:2,energy:-1},'You get structured practice.',{later:{offset:9,delta:{options:1},text:'An afterschool mentor offers a later introduction.'}}),
S('Use the free library club','Save money, though the group offers fewer specialized resources.',{bonds:1,options:1,skills:{academics:1}},'You learn with shared materials and volunteer support.'),
S('Stay home and help family','Give care and protect cash, but sacrifice extracurricular access.',{bonds:2,energy:-1,options:-1},'Your contribution matters to the household.')]),
M(9,'Elementary school','Choose your sport or your own lane',p=>p.interest==='sport'?'Your early sports sessions have grown more serious. Which sport do you want to develop?':'A sports coach visits school. You can still try a sport, or deepen another interest.',p=>[
...sportNames.map(name=>S(name,`Learn ${name.toLowerCase()} through practice. Training time can compete with school and money.`,{cash:-220,energy:-1,bonds:1,skills:{sport:2}},`You join a ${name.toLowerCase()} program. No scholarship is promised.`,{set:{sport:name,playedSport:true,interest:'sport'}})),
S('Focus on another passion','Build non-sport interests; you may miss team opportunities.',{skills:{art:1,academics:1},energy:1},'Your path continues outside organized sport.',{set:{sport:null}})],'everyday','sport'),
M(10,'Elementary school','Someone notices your potential',p=>p.sport?`A local coach says you could improve in ${p.sport.toLowerCase()}, but a better program is across town.`:'A local mentor invites you to learn with more experienced students. Travel and time are real constraints.',[
S('Travel for extra instruction','Gain specialized coaching or teaching at a monetary cost.',{cash:-380,energy:-2,options:2,skills:{sport:1,academics:1}},'You get more structured feedback, while sacrificing time.'),
S('Practice with nearby friends','Keep transportation easy and build community, with fewer resources.',{bonds:2,skills:{sport:1,art:1},energy:-1},'You learn alongside peers at your own pace.'),
S('Take a seasonal break','Protect your wellbeing, but practice is interrupted.',{energy:2,skills:{sport:-1}},'You recover and keep space for other interests.')]),
M(11,'Middle school','School resources',p=>`Your school can recommend one of three activities. Institutional access varies; this setting has a systemic-barriers rating of ${p.background.friction}/4, which can alter fictional chance odds.`,[
S('Academic competition','Practice and perform under pressure.',{skills:{academics:2},energy:-2,options:1},'You strengthen academic preparation with a demanding schedule.'),
S('Student team or club','Build group experience but accept responsibility to others.',{skills:{sport:1,care:1},bonds:1,energy:-2},'You learn how a group functions.'),
S('Independent projects','Work at your pace with limited outside exposure.',{skills:{tech:1,art:1},energy:1,options:-1},'You discover what keeps you curious when nobody grades it.')]),
M(12,'Middle school','Extra duties at home','A family member needs more help with everyday tasks this season. Your time cannot stretch indefinitely.',[
S('Take on regular caregiving','Help reliably, but lose energy and activity time.',{bonds:2,energy:-2,options:-1,skills:{care:1}},'Your family relies on you.'),
S('Ask adults to share responsibilities','Coordinate support, but risk an uncomfortable conversation.',{bonds:1,energy:-1,options:1},'The schedule gets negotiated instead of assumed.'),
S('Protect your school commitments','Preserve study time, but someone else carries the burden.',{skills:{academics:1},options:1,bonds:-1},'You maintain academic routines with a social cost.')]),
M(12,'Middle school','A competition falls on the same day',p=>p.sport?`Your ${p.sport.toLowerCase()} team has a match on the day of an important school project.`:'Your chosen activity conflicts with an important school project.',[
S('Prioritize the competition','Gain practice or exposure, at a schoolwork cost.',{skills:{sport:2,academics:-1},energy:-2,bonds:1},'You choose an activity commitment.'),
S('Prioritize the project','Protect school preparation, but skip a meaningful event.',{skills:{academics:2,sport:-1},energy:-1,bonds:-1},'You finish the project while missing the activity.'),
S('Explain the conflict and negotiate','Use communication but take on a more complicated schedule.',{skills:{care:1,academics:1},energy:-2,options:1},'You seek a compromise that still costs effort.')]),
M(13,'Teen years','A new club costs money','An instructor offers a more advanced youth program, but fees and transport are not covered.',[
S('Join the advanced club','Spend $620 for access to higher-level practice.',{cash:-620,skills:{sport:1,academics:1},options:2,energy:-2},'You gain structure and visibility at a cost.'),
S('Join a free community alternative','Keep the fee money and rely on volunteer support.',{bonds:2,skills:{sport:1,care:1},energy:-1},'You find a route that costs less but may have fewer facilities.'),
S('Organize something yourself','Create a club; you gain leadership but carry the work.',{skills:{business:1,care:1},bonds:1,energy:-2},'You build an opportunity with limited resources.')]),
M(13,'Teen years','Fitting in is complicated','A popular group makes jokes at someone else’s expense. Standing apart could change your friendships.',[
S('Challenge the remarks directly','Take a social risk to establish a boundary.',{bonds:1,energy:-2,options:-1,skills:{care:1}},'Some people respect you, others pull away.'),
S('Support the person privately','Help without a public clash, but the group continues.',{bonds:2,energy:-1},'You build trust, although the broader problem persists.'),
S('Say nothing','Avoid immediate conflict but damage trust with someone.',{energy:1,bonds:-2},'The moment passes without intervention.')], 'everyday','social'),
M(14,'Teen years','Training or another interest',p=>p.sport?`Your ${p.sport.toLowerCase()} coach recommends extra conditioning. More hours could help, but your health and schoolwork matter.`:'You are offered a structured creative, academic or sports workshop.',[
S('Commit to intensive training','Increase performance through practice at a real energy cost.',{skills:{sport:2},energy:-3,options:1},'You train consistently but feel the burden of the schedule.'),
S('Train moderately and protect rest','Develop steadily without maximizing exposure.',{skills:{sport:1},energy:1,bonds:1},'Your balanced routine leaves space for relationships.'),
S('Try another discipline','Improve flexibility and wider skills, but reduce specialist training.',{skills:{art:1,academics:1,sport:-1},energy:1},'You discover a new way to learn.')], 'everyday','sport'),
M(14,'Teen years','Screen time and private life','Friends are online tonight. You also need rest and have commitments tomorrow.',[
S('Stay connected late','Enjoy social time at the cost of sleep.',{bonds:2,energy:-2},'You share jokes and stories but wake up tired.'),
S('Turn in early','Protect energy and miss the conversation.',{energy:2,bonds:-1},'You feel rested but left out of a few moments.'),
S('Set a time limit','Practice a boundary, but do not fully satisfy either side.',{energy:1,bonds:1,options:-1},'You leave before everyone else and manage the next day.')]),
M(15,'High school','A mentor offers help','An adult can introduce you to a program, but you are already stretched thin.',[
S('Meet weekly with the mentor','Build guidance and connections; sacrifice free time.',{bonds:1,options:2,energy:-2,skills:{academics:1}},'You develop a consistent source of advice.',{set:{mentor:true},later:{offset:10,delta:{options:2},text:'A mentor later provides a reference or introduction.'}}),
S('Meet only when necessary','Keep flexibility, but develop a weaker relationship.',{options:1,energy:1},'You gain occasional advice.'),
S('Find peers to learn with','Build mutual aid without specialist adult guidance.',{bonds:2,skills:{care:1},options:-1},'You learn through shared experience.')]),
M(15,'High school','Summer opportunity','A summer program offers classes, leadership training and new experiences, but it conflicts with paid work.',[
S('Attend the summer program','Pay $400 and devote weeks to learning.',{cash:-400,skills:{academics:2,care:1},options:2,energy:-2},'You gain exposure to new ideas.',{later:{offset:7,delta:{options:1},text:'A summer-program contact invites you to apply for an opportunity.'}}),
S('Work the summer','Add $1,650 to family-accessible savings and learn job habits.',{cash:1650,energy:-2,skills:{business:1}},'You bring in money instead of accumulating formal credentials.'),
S('Volunteer locally','Strengthen relationships but earn little money.',{bonds:2,skills:{care:1},energy:-1},'You make a difference without financial compensation.')]),
M(16,'High school','Leadership has a price','Your team or club needs a leader for a complicated project.',[
S('Run for the leadership role','Gain responsibility, visibility and stress.',{options:2,bonds:1,energy:-2,skills:{business:1}},'You learn to decide amid disagreement.'),
S('Be a dependable teammate','Keep collaborative ties and avoid some administrative burden.',{bonds:2,skills:{care:1},energy:-1},'You help the group function without the title.'),
S('Focus on individual goals','Gain more time to practice alone at a social cost.',{energy:1,skills:{academics:1},bonds:-1},'You follow a private plan rather than leading others.')]),
M(16,'High school','Academics and athletics collide',p=>p.sport?`A ${p.sport.toLowerCase()} showcase overlaps with academic preparation. Recruiters may attend, but nothing is promised.`:'A school showcase overlaps with academic preparation. You must choose where to focus.',[
S('Attend the showcase','Increase visibility and sport performance, but miss study time.',{skills:{sport:2,academics:-1},energy:-2,options:1},'You expose yourself to being noticed, without a guaranteed offer.',{set:{showcase:true}}),
S('Prepare for coursework','Improve grades and qualification, but skip possible recruitment.',{skills:{academics:2,sport:-1},energy:-1,options:1},'You protect one set of possibilities while narrowing another.'),
S('Try to do both','Keep both doors open, with significant fatigue.',{skills:{sport:1,academics:1},energy:-3},'You stretch your schedule to cover both commitments.')],'everyday','sport'),
M(17,'High school','A big exam','The exam matters for some applications, but how much it matters varies by institution and opportunity.',[
S('Study intensely','Improve preparation while sacrificing rest.',{skills:{academics:2},options:1,energy:-2},'Your study habits strengthen, though the result remains uncertain.'),
S('Work more hours','Save $1,300 at the expense of preparation and energy.',{cash:1300,energy:-2,skills:{business:1,academics:-1}},'You put money toward your next step.'),
S('Study with a group','Gain support but less control of the schedule.',{skills:{academics:1},bonds:2,energy:-1},'Other perspectives help you prepare.')]),
M(17,'High school','Recruitment season',p=>p.sport?`A ${p.sport.toLowerCase()} recruiter may review film and results. Your training is ${p.skills.sport}/10. A strong record helps, but opportunity and chance matter.`:'Counselors and programs request applications. Not everyone receives the same support.',p=>p.sport?[
S('Submit an athletic recruiting profile','Pay fees and invest time; an offer is not guaranteed.',{cash:-450,energy:-2,options:1},'You submit film and performance information.',{special:'recruitment',set:{recruited:true}}),
S('Concentrate on non-athletic applications','Prioritize coursework and academic aid instead.',{skills:{academics:2},options:2,energy:-1},'You broaden your plans outside recruitment.'),
S('Ask a community coach for support','Save money but rely on a smaller network.',{bonds:1,skills:{sport:1},energy:-1},'You enlist help without assuming a recruiter will respond.',{special:'recruitment',set:{recruited:true}})]:[
S('Apply broadly','Spend $200 in fees and time for more opportunities.',{cash:-200,options:2,energy:-2},'You widen the set of programs you consider.'),
S('Seek no-fee local options','Lower costs, but choose from fewer programs.',{cash:200,options:1,bonds:1},'You build a practical plan with limited expense.'),
S('Work and explore later','Preserve your flexibility at the cost of early applications.',{cash:950,energy:-2,options:-1},'You save money and postpone a formal path.')], 'everyday','recruit'),
M(18,'Transition','Choose the road after high school','College, vocational training, paid work and a gap year offer different kinds of opportunity. None determines intelligence.',[
S('Four-year college','Simulated net cost $7,500 now; access to degrees with possible debt.',{cash:-7500,energy:-1,options:2},'You enroll in college. Aid and family resources may change the burden.',{set:{route:'college'},later:{offset:6,delta:{options:1},text:'An academic contact shares an opportunity.'}}),
S('Trade or vocational school','Simulated training cost $2,800; targeted hands-on skills.',{cash:-2800,energy:-1,options:1,skills:{craft:1}},'You start vocational training.',{set:{route:'trade'}}),
S('Enter paid work','Earn $1,900 early, but have fewer formal credentials.',{cash:1900,energy:-2,skills:{business:1}},'You start earning while learning on the job.',{set:{route:'work'}}),
S('Take a gap year','Spend $950 on a transition with more freedom and uncertainty.',{cash:-950,energy:1,options:1},'You gain time to consider your next step.',{set:{route:'gap'}})], 'major','transition'),
M(18,'Transition','Choose a specific field',p=>`Your direction is ${({college:'college',trade:'vocational training',work:'paid work',gap:'a gap year'})[p.route]}. Choose what you will actually study or do—not just a vague career category.`,courseCards,'major','education'),
M(19,'Young adulthood','Athletics on campus or outside it',p=>p.sport?`You have trained in ${p.sport.toLowerCase()}. College varsity selection, club sport and paid work pull on your time.`:'Your classmates are organizing sports and academic clubs. Time outside the classroom also shapes your future.',sportCollegeChoices,'everyday','sport'),
M(19,'Young adulthood','The cost of living','Living expenses force a choice between stability, independence and social connections.',[
S('Share a less expensive place','Save $1,600 but accept less privacy.',{cash:1600,bonds:1,energy:-1},'Roommates reduce costs while adding negotiation.'),
S('Live independently','Pay $2,300 for your own space and privacy.',{cash:-2300,energy:2,bonds:-1},'You gain quiet space with higher bills.'),
S('Stay with family or friends','Preserve money, but accept limits on independence.',{cash:1000,bonds:1,options:-1},'A support network makes the transition less expensive.')]),
M(20,'Young adulthood','Learning from someone experienced','A professional or older student offers mentorship. Access depends on networks as well as effort.',[
S('Commit to the mentorship','Invest energy in a long-term professional connection.',{bonds:1,options:2,energy:-2,skills:{academics:1}},'You learn from another person’s experience.',{set:{mentor:true}}),
S('Build a peer study group','Learn collectively; members have limited experience.',{bonds:2,energy:-1,skills:{care:1}},'You strengthen mutual support.'),
S('Earn more this term','Accept $1,650 in extra work instead of more networking.',{cash:1650,energy:-2,options:-1},'You keep finances moving while sacrificing some contacts.')]),
M(20,'Young adulthood','Practice and recovery',p=>p.sport?`Your ${p.sport.toLowerCase()} season has been demanding. You could push harder or protect recovery.`:'Your workload has been demanding. Improving skills still takes time and rest.',[
S('Increase training volume','Gain specialized practice, with higher fatigue and injury exposure.',{skills:{sport:2},energy:-3},'Your skills improve, but the schedule is hard on your body.',{special:'trainingRisk'}),
S('Focus on recovery and steady practice','Protect energy but reduce immediate progress.',{skills:{sport:1},energy:1,options:-1},'You find a sustainable rhythm.'),
S('Take a second job or course','Gain money and broader skills, with less specialization.',{cash:1250,skills:{business:1},energy:-2,skills2:{sport:-1}},'You invest in options beyond one pursuit.')], 'everyday','sport'),
M(21,'Young adulthood','A financial surprise','An unexpected bill arrives. Your earlier choices affect how much flexibility you have.',[
S('Pay from your funds','Avoid additional obligations at the cost of liquidity.',{cash:-1600,energy:1},'You deal with the expense now.'),
S('Ask your network to share the burden','Seek help, but social reciprocity has costs.',{cash:-500,bonds:-1,energy:-1},'Others help, though you feel the obligation to give back.',{when:p=>p.bonds>=5,lock:'Requires relationships 5+'}),
S('Take a payment plan','Keep cash now but add a longer-term obligation.',{debt:2100,options:-1,energy:1},'You preserve liquidity while taking on debt.')]),
M(21,'Young adulthood','A chance to build a résumé','An internship, an apprenticeship, a paid role or an independent project could open doors.',[
S('Take a low-paid internship','Gain access but spend $650 on transport and time.',{cash:-650,options:2,energy:-2,skills:{business:1}},'You gain a credential, but unpaid work is easier with financial support.'),
S('Take paid work instead','Earn $2,200 and gain practical experience.',{cash:2200,energy:-2,skills:{business:1}},'You strengthen your finances but miss some formal networking.'),
S('Build an independent project','Make evidence of your skills with uncertain recognition.',{cash:-300,energy:-1,skills:{art:1,tech:1},options:1},'You make something real without waiting for permission.')]),
M(22,'Early career','A possible elite sports future',p=>p.sport?`Your ${p.sport.toLowerCase()} experience has reached a decision point. Professional competition is exceptionally uncertain. Your game practice level is ${p.skills.sport}/10.`:'Not everyone plays organized sports, but everyone faces uncertain career ambitions.',proOptions,'major','pro'),
M(22,'Early career','Select your first specific career',p=>`Your education route is ${p.route}; your ${p.major?`college focus is ${majorNames[p.major]}`:`training field is ${tradeNames[p.program]||workNames[p.program]||'still evolving'}`}. Choose a job, not just a broad category.`,careerOptions,'major','career'),
M(23,'Early career','Your first employment contract',p=>`You work as ${careerInfo[p.career]?.name||'an early-career professional'}. Earnings help, but employment terms can be negotiated or lost.`,[
S('Negotiate pay and expectations','Possible higher pay, but create uncomfortable tension.',{cash:1750,energy:-2,options:1,skills:{business:1}},'You ask for better terms with no guarantee of future approval.'),
S('Accept stability and build reputation','Predictable income, but weaker immediate leverage.',{cash:1200,bonds:1,energy:-1},'You settle into your work and learn its expectations.'),
S('Reduce hours for training','Make less income now to pursue a future skill.',{cash:-800,skills:{academics:1,tech:1},energy:1,options:1},'You invest in skills instead of current earnings.')]),
M(24,'Early career','The qualification gap',p=>`Advancing in ${careerInfo[p.career]?.name||'your field'} may require credentials, mentorship or demonstrable work.`,[
S('Take a professional course','Spend $1,900 and substantial time.',{cash:-1900,energy:-2,skills:{tech:1,academics:1},options:2},'You add formal training, but it is not a guaranteed promotion.'),
S('Learn on the job','Build practical skill without tuition, with slower credential recognition.',{cash:650,skills:{craft:1,business:1},energy:-1},'You become more capable without a new certificate.'),
S('Strengthen relationships at work','Invest in people, but sacrifice some individual advancement.',{bonds:2,energy:-1,options:1},'New connections help you understand how the organization works.')]),
M(25,'Adulthood','A relationship needs attention','Someone close to you asks for more of your time while work is becoming demanding.',[
S('Make reliable time','Strengthen a relationship, but reduce paid hours.',{bonds:2,energy:-1,cash:-700},'You become more present at an opportunity cost.'),
S('Keep pursuing your career','Improve your financial position, but increase distance.',{cash:1500,bonds:-2,energy:-1},'You achieve a goal while putting a relationship under strain.'),
S('Negotiate a workable routine','Make a compromise that requires organization.',{bonds:1,options:1,energy:-2},'Neither person gets everything, but both have more clarity.')]),
M(26,'Adulthood','An offer in another city','A better-paying job is available elsewhere. The move could improve your prospects but disrupt your existing life.',[
S('Move for the offer','Earn a larger income later but pay $2,700 to relocate.',{cash:-2700,options:2,bonds:-2,energy:-1},'You change places and sacrifice familiar support.',{later:{offset:4,delta:{cash:2000},text:'The new location provides a paid opportunity.'}}),
S('Stay with your network','Maintain relationships and avoid moving costs.',{bonds:2,options:-1,energy:1},'You keep stability but miss a higher-paying possibility.'),
S('Request remote or flexible terms','Preserve some ties, but negotiation may fail.',{cash:-450,bonds:1,options:1,energy:-1},'You test whether a less disruptive arrangement is possible.')]),
M(28,'Adulthood','What is graduate study for?',p=>p.major==='psych'?'Your psychology foundation could lead toward clinical training, research or non-clinical work. Professional practice requires qualifications and licensing beyond an undergraduate degree.':'An advanced credential might deepen expertise, but cost and lost earnings matter.',p=>[
S(p.major==='psych'?'Begin accredited clinical graduate training':'Return to advanced study','Take on substantial study costs and time; qualifications can unlock work.',{cash:-6200,debt:2400,energy:-2,skills:{academics:2,care:1},options:2},'You pursue additional credentials with a larger financial burden.',{set:{grad:true}}),
S('Get a shorter professional certificate','Pay $1,300; build narrower but practical skills.',{cash:-1300,energy:-1,options:1,skills:{tech:1,craft:1}},'You gain focused training without a long program.'),
S('Keep working and learning informally','Avoid tuition, though some doors still require credentials.',{cash:1600,energy:-1,skills:{business:1}},'You grow through experience instead of formal study.')], 'major','education'),
M(30,'Adulthood','Career change',p=>`Your current work is ${careerInfo[p.career]?.name||'still developing'}. Are you willing to change fields with uncertain results?`,p=>[
S('Stay and seek advancement','Use your experience and relationships, but limit exploration.',{cash:2000,options:1,energy:-2},'You deepen work in your current field.'),
S('Pivot toward tech or business','Pay for training and accept a transition period.',{cash:-2400,skills:{tech:1,business:1},energy:-2,options:2},'You work toward a new role.',{set:{career:'it'}}),
S('Pivot toward education or community work','Build purpose and community, with different earnings.',{cash:-1350,skills:{care:1,academics:1},bonds:2},'You explore teaching and community-centered work.',{set:{career:'community'}}),
...(p.major==='psych'&&p.flags.grad?[S('Move toward supervised counseling work','Use graduate study; supervised experience and licensing are still necessary.',{cash:950,energy:-2,skills:{care:2},options:1},'You begin a clinical-career pathway, not an instant license.',{set:{career:'therapist'}})]:[]),
...(p.major==='prelaw'&&p.flags.grad?[S('Pursue the legal profession','Take a law-focused path subject to necessary qualifications.',{cash:-1100,energy:-2,options:2},'You invest further in legal training and professional steps.',{set:{career:'lawyer'}})]:[])], 'major','career'),
M(32,'Adulthood','A loved one needs care','A relative is experiencing a demanding period. Supporting them could require money, time or a changed schedule.',[
S('Contribute money','Pay $2,200, preserving more of your work schedule.',{cash:-2200,bonds:2,energy:-1},'You give direct financial help with less day-to-day involvement.'),
S('Provide hands-on care','Give time and energy at a financial cost.',{cash:-850,bonds:2,energy:-3,skills:{care:1}},'You become part of the care routine.'),
S('Coordinate shared support','Build a network but accept the effort of organizing people.',{cash:-350,bonds:1,energy:-2,options:1},'Care gets distributed imperfectly.')]),
M(35,'Midlife','Buy, rent or move?','Housing affects financial security, stability, travel and relationships. No option is universally best.',[
S('Put money toward a home','Spend $7,500, trade liquidity for greater stability.',{cash:-7500,options:1,energy:-1},'You gain housing stability with a major financial commitment.'),
S('Keep renting flexibly','Preserve mobility and cash, with more exposure to rent changes.',{cash:1300,energy:1,options:-1},'You prioritize flexibility over ownership.'),
S('Share housing or downsize','Lower expenses, but negotiate space and privacy.',{cash:2600,bonds:1,energy:-1},'You create financial space with a lifestyle trade-off.')]),
M(38,'Midlife','Care versus career',p=>`Your career as ${careerInfo[p.career]?.name||'a worker'} offers a major new responsibility. At the same time someone close needs significant care.`,[
S('Take the demanding promotion','Increase cash by $4,400, but reduce energy and time with others.',{cash:4400,bonds:-2,energy:-3,options:2},'You grow professionally while relationships feel the absence.'),
S('Prioritize care for now','Support loved ones but forgo a financial opportunity.',{cash:-2200,bonds:3,energy:-2},'You are present during a difficult period.'),
S('Negotiate work and care arrangements','Seek a compromise that costs time and coordination.',{cash:-900,energy:-2,bonds:2,options:1},'Your plan depends on other people cooperating.',{later:{offset:3,delta:{bonds:1,energy:1},text:'Someone offers to share the caregiving load.'}})], 'major','ethics'),
M(41,'Midlife','A shortcut with ethical strings','Someone influential offers a quick promotion if you overlook an unfair hiring practice. Pressure exists in many kinds of institutions.',[
S('Refuse the arrangement','Protect your values and risk financial retaliation.',{cash:-1500,energy:-1,bonds:1},'You refuse the favor without a guaranteed reward.'),
S('Document and challenge the practice','Seek accountability but expose yourself to conflict.',{cash:-900,energy:-3,options:1,bonds:1},'Others may support you—or close ranks.'),
S('Accept the opportunity','Gain money and access, but compromise trust.',{cash:2700,options:1,bonds:-3,energy:-1},'The advantage may carry a moral and social cost.')], 'major','ethics'),
M(44,'Midlife','Community resources are cut','Your town threatens to close a youth program. Your response competes with work, family and rest.',[
S('Organize people to respond','Mobilize support while risking exhaustion.',{bonds:2,energy:-2,options:1,skills:{care:1}},'You build collective action that may or may not succeed.'),
S('Donate financially','Spend $1,700 to support the program.',{cash:-1700,bonds:1},'You contribute resources without taking on all of the work.'),
S('Focus on your own household','Preserve stability with less influence on the wider community.',{cash:850,energy:1,bonds:-1},'You choose a narrower responsibility.')]),
M(47,'Midlife','The second career','Your experience could help you lead, mentor, specialize or change directions.',[
S('Seek management','Make more money, but bear greater responsibility.',{cash:2700,energy:-2,options:2,skills:{business:1}},'You manage others rather than only your own work.'),
S('Teach or mentor younger people','Build relationships and meaning, but earn less.',{cash:-700,bonds:2,skills:{care:1},energy:-1},'You share knowledge without knowing its long-term impact.'),
S('Start independent work','Gain control while facing variable income.',{cash:-1300,energy:-2,skills:{business:2},options:1},'You begin a small venture.',{set:{career:'freelance'}})], 'everyday','career'),
M(50,'Midlife','What to do with extra savings?',p=>`You have ${usd(p.cash)} in cash and ${usd(p.debt)} in debt. You may have both personal goals and obligations.`,[
S('Pay down up to $3,000 of debt','Reduce what you owe, but preserve less cash.',{repay:3000,energy:1},'You reduce obligations where possible.'),
S('Help younger relatives with education','Spend $2,000 and support another person’s options.',{cash:-2000,bonds:2,options:-1},'Your money benefits someone else.'),
S('Save for emergencies','Protect money and avoid new risks, but skip opportunities.',{cash:1300,energy:1,options:-1},'You build a cushion rather than taking a chance.')]),
M(53,'Midlife','Burnout or momentum?','Years of work and obligations have made your energy finite.',[
S('Accept another demanding contract','Earn $3,900 with a substantial energy cost.',{cash:3900,energy:-3,options:1},'You advance materially and feel the strain.'),
S('Reduce your hours','Recover energy at an income cost.',{cash:-1700,energy:3,bonds:1},'You create time to rest and reconnect.'),
S('Ask trusted colleagues to share work','Depend on relationships and coordination.',{cash:-650,bonds:1,energy:2},'Cooperation helps, though the work does not disappear.',{when:p=>p.bonds>=5,lock:'Requires relationships 5+'})]),
M(56,'Later adulthood','A new skill at fifty-six','You have an opportunity to learn something new. Growth is not limited to youth.',[
S('Study technology','Pay for a course and build unfamiliar skills.',{cash:-950,skills:{tech:2},energy:-1},'You prove that learning can continue.'),
S('Return to a sport, art or hobby','Support health and personal meaning, but spend money.',{cash:-650,skills:{sport:1,art:1},energy:2},'You reconnect with activities you value.'),
S('Prioritize relaxation','Protect energy, but decline a new project.',{energy:3,options:-1},'You choose not to optimize every moment.')]),
M(59,'Later adulthood','Mentoring the next generation','A younger person asks for advice. You remember how opportunities and expectations shaped you.',[
S('Mentor consistently','Build connection, but take on responsibility.',{bonds:2,energy:-2,skills:{care:1}},'You provide steady guidance.'),
S('Offer an introduction','Use a network without a long-term commitment.',{options:-1,bonds:1,energy:-1},'You open a door, but cannot control what happens next.'),
S('Decline and protect your capacity','Make room for your own needs, but miss a bond.',{energy:2,bonds:-1},'You choose a boundary.')]),
M(62,'Later adulthood','Retirement and responsibility','Some people in your family hope you will provide money or care; your future also matters.',[
S('Give financial support','Spend $2,700 and strengthen your connections.',{cash:-2700,bonds:2,energy:-1},'You contribute to someone’s needs.'),
S('Offer time rather than money','Preserve funds but spend energy.',{bonds:2,energy:-2},'Your presence matters materially.'),
S('Prioritize your own retirement plan','Secure resources but disappoint others.',{cash:1200,bonds:-1,energy:1},'You protect your ability to support yourself.')]),
M(65,'Later adulthood','Keep working, change roles or retire',p=>`You have followed a career in ${careerInfo[p.career]?.name||'work and service'}. You may now choose how to use your time.`,[
S('Continue part-time','Keep reduced income and a work community; spend energy.',{cash:900,bonds:1,energy:-2},'You maintain a link to paid work.',{set:{workMode:'part-time',retired:false}}),
S('Retire from paid work','Get energy back, but lose recurring employment income; living costs remain.',{cash:-1100,energy:3,options:-1},'You redirect time away from employment.',{set:{workMode:'retired',retired:true}}),
S('Consult or mentor occasionally','Earn modestly, using accumulated experience.',{cash:850,bonds:2,energy:-1},'You contribute selectively.',{set:{workMode:'consulting',retired:false}})]),
M(69,'Later adulthood','An unexpected request','A community group asks you to fund a small project. You want to help, but cannot fund every worthwhile goal.',[
S('Fund the project','Spend $2,200 and accept uncertainty about impact.',{cash:-2200,bonds:2,options:1},'You invest resources in other people.'),
S('Offer practical advice','Contribute knowledge rather than money.',{bonds:1,energy:-2},'The group benefits from experience.'),
S('Decline the request','Preserve cash and wellbeing but lose an opportunity to serve.',{cash:500,energy:1,options:-1},'You set a limit on your obligations.')]),
M(72,'Later adulthood','What relationships remain?','An old friend wants to reconnect. History, obligations and time all influence your answer.',[
S('Plan time together','Strengthen an old bond, but travel and coordination cost something.',{cash:-450,bonds:2,energy:-1},'You renew a friendship.'),
S('Stay in touch from a distance','Maintain connection with less travel but less closeness.',{bonds:1,energy:1},'You keep the door open.'),
S('Invest in new relationships','Build fresh community but miss an older connection.',{options:1,bonds:1,energy:-1},'You seek people in your current chapter.')]),
M(75,'Reflection','What does a whole life reveal?','Your life contains decisions, constraints, luck, hardship, access, relationships and unfinished stories. None can be reduced to an intelligence ranking.',[
S('Value the questions you kept asking','Honor learning and curiosity, even when answers remained uncertain.',{skills:{academics:1},energy:1},'Your curiosity persisted outside grades.'),
S('Value the people you affected','Honor relationships rather than numerical success.',{bonds:1,energy:-1},'You remember people whose lives connected to yours.'),
S('Value the freedom you created for others','Honor opportunity, while recognizing your limitations.',{options:1,bonds:1},'You reflect on how your actions may have changed possibilities.')], 'reflection','reflection')
];
// Additional circumstances, agency, emotional life and enterprise decisions.
// These are entirely fictional mechanics, NOT estimates of human behavior.
const baseScenes=scenes.slice();
const extraScenes=[
M(6,'Childhood','Your family has a difficult week','An adult at home has less time than usual. You cannot control their workload, but you can respond to the change.',[
 S('Ask another trusted adult for support','Build another connection; asking can feel uncomfortable.',{bonds:1,belonging:1,energy:1},'Someone else helps carry the week.',{set:{askedForSupport:true}}),
 S('Take on a small responsibility','Help at home, while having less time for yourself.',{bonds:1,energy:-1,purpose:1},'You feel useful and also more tired.'),
 S('Spend time on your own interests','Protect personal space; family tasks may wait.',{energy:1,purpose:1,bonds:-1},'You get room to think while household expectations remain.')],'everyday','emotions'),
M(8,'Elementary school','A teacher misunderstands you','A teacher interprets your quietness or excitement as disrespect. How will you try to be understood?',[
 S('Ask the teacher to hear your perspective','Risk discomfort to explain what you meant.',{energy:-1,options:1,purpose:1},'You try to make your perspective visible.',{special:'socialRepair',set:{spokeUp:true}}),
 S('Ask a trusted adult to help you explain','Use a relationship to mediate misunderstanding.',{bonds:1,energy:-1,belonging:1},'Another person helps translate your experience.'),
 S('Let it pass this time','Avoid confrontation but remain misunderstood.',{energy:1,belonging:-1,stress:1},'The incident passes without your perspective being fully heard.')],'everyday','emotions'),
M(10,'Elementary school','Practice when no one is watching',p=>`You have been exploring ${p.sport||p.interest||'different interests'}. Progress is slow and nobody is promising a reward.`,[
 S('Practice consistently','Put time into one skill even without recognition.',{energy:-2,skills:{sport:1,academics:1},purpose:1},'You discover how repetition changes a skill.',{set:{disciplined:true}}),
 S('Try something new each week','Build breadth and curiosity, but specialize less.',{options:1,skills:{art:1,tech:1},energy:-1},'You expand your frame of reference.'),
 S('Choose free time with friends','Develop relationships without maximizing every hour.',{bonds:1,belonging:2,energy:1},'Your unstructured time matters to you.')],'everyday','interests'),
M(12,'Middle school','An unfair rumor','A rumor begins about another student. The popular group expects everyone to repeat it.',[
 S('Challenge it publicly','Defend the classmate while risking exclusion.',{bonds:1,options:-1,stress:1,purpose:1},'You refuse to repeat a claim you cannot verify.',{special:'socialRepair'}),
 S('Speak privately with the classmate','Offer connection without making the conflict public.',{bonds:2,belonging:1,energy:-1},'You learn their perspective.'),
 S('Stay out of it','Protect yourself from group conflict; the rumor continues.',{energy:1,belonging:-1},'Your silence has consequences you may never observe.')],'everyday','ethics'),
M(13,'Teen years','Who are you outside grades?',p=>`You have begun comparing yourself with classmates. You feel pulled between ${p.priority.toLowerCase()} and others' expectations.`,[
 S('Explore an identity beyond school','Join a hobby group or club without aiming to win.',{cash:-100,purpose:2,energy:-1},'You begin to value something not graded.',{set:{identityOutsideAchievement:true}}),
 S('Compete for academic rank','Work hard under public comparison.',{skills:{academics:2},stress:2,energy:-2,options:1},'You gain practice but feel the pressure of comparison.'),
 S('Spend more time with your people','Build belonging while doing fewer extra activities.',{bonds:2,belonging:2,options:-1},'You prioritize being known rather than being ranked.')],'everyday','emotions'),
M(14,'Teen years','The group chat goes wrong','A joke in a group chat hurts a friend, but admitting it was insensitive may embarrass you.',[
 S('Apologize and listen','Acknowledge the harm without demanding immediate forgiveness.',{bonds:1,purpose:1,energy:-1},'You try to repair trust.',{special:'socialRepair',set:{accountability:true}}),
 S('Explain why you did not mean harm','Defend your intent while risking dismissal of the other perspective.',{stress:1,bonds:-1,energy:-1},'Your intent and their experience remain different.'),
 S('Leave the chat','Stop the argument but avoid a direct conversation.',{energy:1,belonging:-1},'You escape the conflict without resolving it.')],'everyday','social'),
M(15,'High school','A party or a quiet evening','A friend is hosting a weekend party. You have plans the next morning; nobody has to drink for the event to matter.',[
 S('Go and set a time to leave','Spend time with peers while keeping a schedule.',{bonds:1,belonging:1,energy:-1},'You participate without abandoning your other commitments.',{set:{socialStyle:'balanced'}}),
 S('Stay home to rest','Protect recovery at the cost of some social experiences.',{energy:2,belonging:-1,stress:-1},'You return to school rested.',{set:{socialStyle:'quiet'}}),
 S('Stay out late','Make spontaneous memories but lose sleep.',{bonds:2,energy:-2,stress:1},'You feel connected, but the next morning is harder.',{special:'partyOutcome',set:{socialStyle:'frequent'}})],'everyday','party'),
M(16,'High school','A friendship becomes one-sided','You are always the one reaching out. You value the friendship, but feel unseen.',[
 S('Talk about the imbalance','Risk an awkward conversation to describe what you need.',{stress:1,bonds:1,purpose:1},'You put your needs into words.',{special:'socialRepair',set:{clearBoundaries:true}}),
 S('Continue doing all the work','Keep the relationship going at a personal cost.',{bonds:1,energy:-2,stress:2},'The friendship continues but the imbalance persists.'),
 S('Step away respectfully','Protect your time while grieving a familiar connection.',{bonds:-1,stress:-1,purpose:1},'You create a boundary without knowing what comes next.')],'everyday','emotions'),
M(17,'High school','How much does excellence cost?',p=>`You have made progress in ${p.sport||p.interest||'school and life'}. A coach, teacher or supervisor tells you to become exceptional you must prioritize it above almost everything.`,[
 S('Pursue elite performance','Choose intense specialization and sacrifice recovery.',{skills:{sport:1,academics:1},energy:-3,stress:2,recognition:1},'You start chasing exceptional achievement, but not everyone benefits equally from the same intensity.',{set:{eliteMindset:true}}),
 S('Train hard with boundaries','Choose sustainable improvement, knowing progress may be slower.',{skills:{sport:1,academics:1},energy:-1,purpose:1},'You define ambition on terms you can sustain.'),
 S('Explore other goals','Make space for another version of success.',{skills:{art:1,care:1},belonging:1,options:1},'You resist having one measure define your future.')],'major','ambition'),
M(18,'Transition','Family expectations versus your plans',p=>`Your family has strong opinions about your ${p.route||'post-school'} pathway. Their hopes for you do not always match your priorities.`,[
 S('Explain your choice and listen','Try for understanding without promising agreement.',{bonds:1,stress:1,purpose:1},'You make your reasoning visible to people who see the problem differently.',{special:'socialRepair'}),
 S('Follow the advice for now','Gain support but postpone a personal ambition.',{cash:500,bonds:1,purpose:-1},'You protect a relationship while wondering about the path not taken.'),
 S('Choose independently despite objections','Strengthen autonomy but risk conflict and less support.',{purpose:2,options:1,bonds:-2,stress:1},'You choose your path without guaranteed approval.',{set:{independentChoice:true}})],'major','emotions'),
M(19,'Young adulthood','Your first big social circle',p=>p.route==='college'?'On campus, new friends invite you into a group where you feel both excited and out of place.':'At your new workplace or training program, you meet a group with a very different background from yours.',[
 S('Listen first, then share your story','Spend time building reciprocal trust.',{bonds:2,belonging:1,energy:-1},'You find common ground across different experiences.'),
 S('Act more confident than you feel','Make a strong impression while managing the strain.',{options:1,bonds:1,stress:2},'Other people see your confidence, but not necessarily your experience.'),
 S('Keep your circle small','Protect privacy while developing fewer new connections.',{energy:1,belonging:-1,purpose:1},'Your social world stays manageable.')],'everyday','social'),
M(19,'Young adulthood','A college party',p=>p.route==='college'?'A residence-hall party is happening tonight. You have classes, practice, or work tomorrow.':'Friends from a nearby college invite you to their weekend party. You have responsibilities tomorrow.',[
 S('Go to connect, leave early','Enjoy people and preserve much of tomorrow.',{bonds:2,energy:-1,belonging:1},'You gain shared memories without staying the whole night.',{set:{partyPreference:'sometimes'}}),
 S('Stay the whole night','Enjoy the social moment, but give up sleep and prep time.',{bonds:2,energy:-3,stress:1},'You have fun, but your next obligation gets harder.',{special:'partyOutcome',set:{partyPreference:'frequent'}}),
 S('Choose a smaller gathering instead','Spend time with a few people on terms you prefer.',{bonds:1,energy:1,belonging:1},'You learn that belonging does not require a crowd.',{set:{partyPreference:'small'}}),
 S('Skip and study or rest','Protect your needs while missing part of the social scene.',{energy:2,skills:{academics:1},belonging:-1},'You prioritize another commitment.',{set:{partyPreference:'rare'}})],'everyday','party'),
M(20,'Young adulthood','How often will you go out?',p=>`People around you are establishing routines. So far your social style is ${p.flags.partyPreference||p.flags.socialStyle||'undecided'}. You can change your habits.`,[
 S('Go out most weekends','Develop a large social network but lose more time and money.',{cash:-650,bonds:2,belonging:2,energy:-2,stress:1},'Your calendar fills with social events.',{set:{partyFrequency:'often'},later:{offset:4,delta:{energy:-1},text:'Several busy weeks leave you short of recovery time.'}}),
 S('Go out occasionally','Maintain a balance that still requires planning.',{cash:-240,bonds:1,belonging:1,energy:-1},'You make time for people without structuring your whole week around events.',{set:{partyFrequency:'sometimes'}}),
 S('Mostly stay in or host quiet evenings','Keep routines and spending stable, but some friendships need extra outreach.',{cash:150,energy:2,belonging:-1},'You protect recovery and choose a smaller social world.',{set:{partyFrequency:'rare'}})],'everyday','party'),
M(20,'Young adulthood','An invitation to belong','A student organization or workplace group offers you a role, but others expect you to change your style to fit in.',[
 S('Join without changing your boundaries','Seek connection while being clear about your limits.',{bonds:1,belonging:2,stress:1},'You test whether belonging can accommodate your differences.'),
 S('Blend in to avoid friction','Gain short-term acceptance at the cost of some authenticity.',{bonds:2,belonging:1,purpose:-1,stress:1},'Your outward behavior does not show your internal conflict.'),
 S('Find another group','Spend time searching for a more comfortable community.',{energy:-1,purpose:1,options:1},'You keep looking for people who share your values.')],'everyday','social'),
M(21,'Young adulthood','Drinking at a party',p=>p.route==='college'?'At a college party, friends offer you alcohol. You are 21 in this simulated US setting and can legally choose whether to drink.':'At a celebration with friends and coworkers, alcohol is being served. You are 21 in this simulated US setting.',[
 S('Do not drink','Keep a clear head and participate socially on your terms.',{energy:1,purpose:1,belonging:1},'You socialize without drinking.',{set:{drinkingPattern:'abstinent'}}),
 S('Have a drink and arrange a safe ride','Spend on a drink while maintaining clear transport plans; social outcomes are uncertain.',{cash:-35,bonds:1,energy:-1},'You make a limited choice and avoid driving after drinking.',{special:'adultPartyOutcome',set:{drinkingPattern:'occasional'}}),
 S('Drink more than you intended','Give in to social pressure, with greater uncertainty and real safety risks.',{cash:-125,energy:-2,stress:1},'You notice the pressure to keep up with others.',{special:'excessDrinking',set:{drinkingPattern:'frequent'}}),
 S('Leave when pressured','Honor a personal boundary but miss part of the night.',{energy:2,belonging:-1,purpose:1},'You leave safely without explaining your decision to everyone.',{set:{drinkingPattern:'abstinent',boundariesAroundAlcohol:true}})],'major','party'),
M(21,'Young adulthood','A friend does not seem safe','At a gathering, a friend appears impaired and wants to travel alone. Your immediate obligations are real, but so is concern for them.',[
 S('Stay and help arrange safe transport','Invest time and care rather than letting them travel impaired.',{energy:-2,bonds:2,purpose:1,stress:1},'You help your friend find a safe ride or trusted support.',{set:{helpedFriend:true}}),
 S('Ask a sober person or staff member to help','Share the responsibility while protecting your own safety.',{bonds:1,energy:-1,options:1},'You enlist help rather than managing the situation alone.'),
 S('Tell them to stay and contact someone trusted','Try to set a clear safety boundary from where you are.',{energy:-1,stress:1,bonds:1},'You encourage a safer option without guaranteeing that they will listen.')],'everyday','ethics'),
M(22,'Early career','Is your network a genuine friendship?','A contact can introduce you to an influential employer. They also act dismissively toward one of your closest friends.',[
 S('Challenge the disrespect','Protect a friend while jeopardizing the introduction.',{purpose:2,bonds:1,options:-1,stress:1},'You make a relationship boundary visible.',{special:'socialRepair'}),
 S('Use the introduction and keep distance','Try to gain the opportunity without endorsing the behavior.',{options:2,stress:1,purpose:-1},'Your actions and values may remain in tension.'),
 S('Avoid the contact entirely','Preserve autonomy but lose a possible opening.',{bonds:1,purpose:1,options:-1},'You decline the opportunity on your own terms.')],'major','ethics'),
M(23,'Early career','The comparison trap',p=>`Someone from school seems to be far ahead in money, career or visibility. You currently work toward ${careerInfo[p.career]?.name||'a new direction'}.`,[
 S('Use the comparison as information','Ask what skills and conditions contributed to their result.',{skills:{business:1},stress:-1,options:1},'You learn without assuming the difference is intelligence.'),
 S('Double your workload','Increase effort and exposure while sacrificing rest.',{cash:800,skills:{academics:1},energy:-2,stress:2},'You pursue the visible result more intensely.'),
 S('Step away from the comparison','Protect your sense of meaning rather than competing for appearances.',{purpose:2,energy:1,recognition:-1},'You reconsider what success means to you.')],'everyday','ambition'),
M(24,'Early career','An idea for a business',p=>`You see a problem in ${p.sport?'sports and youth programs':'your work or community'} that a small business might help solve. Having an idea is not the same as having customers.`,[
 S('Interview potential customers','Use evenings to discover whether people actually need your solution.',{cash:-250,energy:-1,skills:{business:2},options:1},'You gather evidence before risking large sums.',{set:{businessInterest:true,validatedIdea:true}}),
 S('Build a prototype','Invest money and creative energy in a first version.',{cash:-800,energy:-2,skills:{tech:1,business:1},purpose:1},'You create something tangible with uncertain demand.',{set:{businessInterest:true,prototype:true}}),
 S('Keep your present job for now','Preserve stability while learning from others.',{cash:500,energy:1,options:-1},'You delay entrepreneurship; this need not be your only chance.')],'everyday','business'),
M(25,'Adulthood','How to repair a deep disagreement','A partner, family member, or close friend says you have not been listening. You remember the same interactions differently.',[
 S('Ask for their perspective without arguing','Listen and acknowledge that experiences can diverge.',{bonds:2,belonging:1,energy:-1,stress:1},'The conversation becomes more specific, though not everything is settled.',{special:'socialRepair'}),
 S('Describe your own needs clearly','Assert your point of view while risking escalation.',{purpose:1,bonds:-1,stress:1},'Your experience becomes visible, but the conversation is tense.'),
 S('Take space and agree to revisit it','Protect short-term calm but leave a future responsibility.',{energy:1,stress:-1,bonds:-1},'You postpone the conversation instead of resolving it immediately.',{later:{offset:5,delta:{bonds:-1,stress:1},text:'The unresolved conversation returns at an inconvenient time.'}})],'major','emotions'),
M(26,'Adulthood','A choice about public recognition','You have been doing good work, but someone more visible receives public credit. You can confront the situation or continue quietly.',[
 S('Present evidence of your contributions','Advocate for recognition at a political cost.',{energy:-1,options:1,stress:1,recognition:1},'You advocate for your work.',{special:'recognition'}),
 S('Ask colleagues to advocate together','Build shared recognition instead of an individual spotlight.',{bonds:2,energy:-1,recognition:1},'Other people understand the contributions better.'),
 S('Focus on the work, not the credit','Preserve energy but risk missing a future opportunity.',{purpose:1,energy:1,options:-1},'You choose meaning over immediate recognition.')],'everyday','ambition'),
M(27,'Adulthood','Love, partnership, and autonomy','A person you care about wants a clearer commitment while you are considering a major professional move.',[
 S('Build a committed partnership','Invest mutual effort while accepting compromise.',{bonds:2,belonging:2,energy:-1,purpose:1},'You and another person start building a shared plan.',{set:{partnered:true}}),
 S('Pursue the move and keep things open','Prioritize movement and independence while accepting uncertainty.',{options:2,bonds:-1,purpose:1,stress:1},'You choose flexibility over commitment.',{set:{partnered:false}}),
 S('Have an honest conversation without deciding yet','Seek clarity while staying with uncertainty.',{bonds:1,stress:1,purpose:1},'Neither person gets a guarantee, but both hear the truth.',{special:'socialRepair'})],'major','emotions'),
M(28,'Adulthood','Do you want to be the best?',p=>`You have experience in ${careerInfo[p.career]?.name||'your field'}. A respected person tells you that reaching the top takes years of deliberate practice, strategic support, and luck.`,p=>[
 S('Pursue exceptional mastery','Develop a focused long-term goal and accept added pressure.',{energy:-3,stress:2,skills:{[careerInfo[p.career]?.skill||'academics']:2},recognition:1,purpose:1},'You commit to an elite standard, but not necessarily a higher quality of life.',{set:{excellence:'elite'}}),
 S('Become highly capable with a sustainable routine','Advance while protecting relationships and recovery.',{energy:-1,stress:-1,purpose:2,skills:{[careerInfo[p.career]?.skill||'academics']:1}},'You define excellence more broadly.',{set:{excellence:'sustainable'}}),
 S('Use your skills to help others grow','Shift focus to service and developing new talent.',{bonds:2,belonging:1,skills:{care:1},options:1},'You make mastery something shared.',{set:{excellence:'mentorship'}})],'major','ambition'),
M(29,'Adulthood','A rejection you did not expect',p=>`You apply for a selective opportunity in ${careerInfo[p.career]?.name||'your chosen field'}. Your qualifications are real, but competition and evaluation are imperfect.`,p=>[
 S('Seek feedback and reapply','Improve your approach, while risking further disappointment.',{skills:{[careerInfo[p.career]?.skill||'academics']:1},stress:1,energy:-1,options:1},'You try again, knowing a second application is not guaranteed to succeed.',{special:'recognition'}),
 S('Take a different path','Use the setback to explore another setting.',{options:1,purpose:1,recognition:-1},'You change the measure of success rather than abandoning growth.'),
 S('Pause before making a big change','Recover and avoid a reactive decision.',{energy:2,stress:-2,options:-1},'You make space to process the rejection.')],'everyday','emotions'),
M(30,'Adulthood','Who counts as your family?',p=>p.flags.partnered?'You and your partner discuss the future. Shared plans require compromise and resources.':'People close to you ask how you want your home and family life to develop. There is no universal timetable.',[
 S('Make a long-term shared home plan','Invest in stability, even when it narrows future flexibility.',{cash:-1500,bonds:2,belonging:2,options:-1},'You build a shared household.',{set:{sharedHome:true}}),
 S('Build a chosen family and friendships','Invest deeply in people without committing to one conventional life structure.',{bonds:2,belonging:2,energy:-1},'Your support network grows beyond formal labels.',{set:{chosenFamily:true}}),
 S('Prioritize independence for now','Protect mobility and personal focus, with some relational distance.',{options:2,energy:1,bonds:-1},'You organize life around personal freedom.',{set:{sharedHome:false}})],'major','social'),
M(31,'Adulthood','A friendship you neglected',p=>`A friend says you are always too busy. Your priorities and stress level (${p.stress}/10 in this fictional model) have affected your calendar.`,[
 S('Make a recurring plan','Rebuild connection at the expense of some free time.',{bonds:2,belonging:2,energy:-1},'Trust grows through consistent action.',{special:'socialRepair'}),
 S('Explain the pressure without promising more','Offer honesty, but little change to your schedule.',{purpose:1,stress:-1,bonds:-1},'Your friend understands more, but still feels distance.'),
 S('Let the friendship change','Accept a smaller connection without forcing it.',{bonds:-1,energy:1,stress:-1},'You allow your social world to evolve.')],'everyday','emotions'),
M(32,'Adulthood','Launch a specific business',p=>`You've ${p.flags.validatedIdea?'talked to potential customers':'considered what a community might need'}. You have ${usd(p.cash)} available, but cash is not the same as reliable future revenue.`,p=>[
 ...[
 ['sports','Sports training and youth coaching','sport'],
 ['tech','Web tools or IT services','tech'],
 ['community','Community education and tutoring','care'],
 ['creative','Design, media or dance studio','art'],
 ['food','Catering or food service','craft'],
 ['repairs','Home repair and trade services','craft']
 ].map(([id,name,skill])=>S(name,`Start a real venture based on ${skill} practice. Setup costs money; customers are uncertain.`,{cash:-2400,stress:2,energy:-2,skills:{business:1,[skill]:1},purpose:1},`You register the idea and begin looking for paying customers for ${name.toLowerCase()}.`,{special:'businessLaunch',set:{ventureKind:id,businessInterest:true}})),
 S('Stay employed and test a side project','Preserve your main income, while leaving less time for expansion.',{cash:-300,stress:1,energy:-1,skills:{business:1},purpose:1},'You postpone a full launch while testing demand.',{set:{businessInterest:true,sideHustle:true}}),
 S('Decide not to start a business','Choose a different kind of ambition without treating entrepreneurship as superior.',{energy:1,stress:-1,purpose:1},'You seek meaningful growth through other routes.')],'major','business'),
M(33,'Adulthood','Your first business customers',p=>p.venture?`Your ${ventureNames[p.venture.kind]||'small business'} has ${p.venture.customers||0} early customer relationships. You need to decide how to build trust.`:'A friend asks you to help with a small business. You can still learn business decisions without owning a company.',p=>[
 S('Provide excellent service before expanding','Invest in quality, and accept slower revenue.',{cash:-600,energy:-2,purpose:1,recognition:1,skills:{business:1}},'You put trust before speed.',{special:'ventureCustomers',when:p=>!!p.venture,lock:'Requires an active business'}),
 S('Run a low-cost advertising campaign','Try to reach more people, paying for uncertain attention.',{cash:-1250,energy:-1,stress:1,skills:{business:1}},'Marketing brings exposure, not guaranteed purchases.',{special:'ventureMarketing',when:p=>!!p.venture,lock:'Requires an active business'}),
 S('Learn how small firms operate','Build transferable skills while retaining your current job.',{skills:{business:2},bonds:1,energy:-1},'You learn from another entrepreneur without risking ownership.')],'everyday','business'),
M(34,'Adulthood','A team or a solo path',p=>p.venture?'Your business needs more help. Hiring has human obligations as well as financial cost.':'An organization asks if you want to lead a new project with others.',[
 S('Commit full-time to your own business','Leave your regular salary and depend on uncertain business income; household expenses remain.',{cash:-600,stress:2,energy:-1,purpose:1},'You become a full-time founder rather than a wage employee. Operating costs and revenue will change with the venture.',{when:p=>!!p.venture,lock:'Requires an active venture',set:{career:'founder',fullTimeFounder:true}}),
 S('Bring in a partner or collaborator','Share authority, workload and eventual rewards.',{cash:-1000,bonds:1,energy:1,stress:1,skills:{business:1}},'You learn that expertise is collective.',{special:'venturePartner',set:{collaborative:true}}),
 S('Work alone and keep control','Retain autonomy but absorb more demands.',{energy:-2,stress:2,options:1},'You become responsible for more outcomes.',{set:{soloBuilder:true}}),
 S('Build a community cooperative project','Make impact a shared decision, while accepting slower processes.',{bonds:2,purpose:2,cash:-750,energy:-1},'A group develops the project together.',{set:{cooperative:true}})],'everyday','business'),
M(35,'Midlife','What your work says about you',p=>`People often judge others by their title. You currently identify with ${careerInfo[p.career]?.name||'your developing roles'}, but feel your life is more complicated.`,p=>[
 S('Build a life outside work','Spend resources on friends, art or sports.',{cash:-650,purpose:2,belonging:2,energy:1},'You invest in an identity that survives job changes.'),
 S('Become known for excellent work','Seek visibility and recognition while increasing pressure.',{skills:{[careerInfo[p.career]?.skill||'academics']:1},recognition:2,energy:-2,stress:2},'Your professional identity becomes more visible.',{special:'recognition'}),
 S('Change how you talk about success','Stop evaluating every part of life by status.',{stress:-2,purpose:1,bonds:1},'You adjust your own internal yardstick.')],'everyday','emotions'),
M(36,'Midlife','Your business faces competition',p=>p.venture?`Another company is offering a cheaper alternative to ${ventureNames[p.venture.kind]||'your business'}. Your cash is ${usd(p.cash)} and your reputation is ${p.recognition}/10.`:'A colleague asks for help adapting to competition. Your own career is changing too.',p=>[
 S('Differentiate on service and quality','Spend time improving outcomes for clients.',{cash:-850,energy:-2,purpose:1,skills:{business:1}},'You pursue a distinctive value rather than copying competitors.',{special:'ventureCustomers',when:p=>!!p.venture,lock:'Requires an active venture'}),
 S('Reduce prices and seek volume','Accept smaller margins in the hope of more customers.',{cash:-1200,stress:2,energy:-1},'You make an uncertain competitive move.',{special:'ventureMarketing',when:p=>!!p.venture,lock:'Requires an active venture'}),
 S('Use transferable skills in your career','Choose flexibility without owning the business.',{options:2,energy:-1,skills:{business:1}},'You develop ways to respond to changing conditions.')],'everyday','business'),
M(37,'Midlife','The emotional cost of ambition',p=>`You have been pursuing ${p.flags.excellence==='elite'?'an exceptional standard':p.priority.toLowerCase()}. Your stress tracker reads ${p.stress}/10. Other people cannot see everything behind that number.`,p=>[
 S('Ask for support and rest','Reduce pressure, even if achievements come more slowly.',{stress:-3,energy:2,bonds:1,recognition:-1},'You deliberately make room for recovery.'),
 S('Keep pursuing the goal intensely','Seek achievement while accepting greater strain.',{skills:{[careerInfo[p.career]?.skill||'academics']:1},recognition:1,stress:2,energy:-2},'You continue chasing an uncertain breakthrough.',{special:'masteryBreakthrough'}),
 S('Change the goal to match your values','Rebalance purpose and reputation.',{purpose:2,stress:-1,options:-1},'You decide that changing direction is not failure.')],'major','ambition'),
M(39,'Midlife','A community tragedy','Something difficult happens in your community. People cope differently, and no one response proves who is stronger.',[
 S('Offer practical assistance','Contribute time, even while managing your own feelings.',{bonds:2,purpose:1,energy:-2,stress:1},'You help with immediate needs.'),
 S('Seek connection and support','Make room to process what happened with others.',{bonds:1,belonging:2,energy:1,stress:-1},'You share the burden without having to solve everything.'),
 S('Give yourself privacy','Protect personal space while remaining aware of others.',{energy:2,belonging:-1,stress:-1},'You process the event privately.')],'everyday','emotions'),
M(40,'Midlife','A selective award or invitation',p=>`Someone nominates you for recognition in ${careerInfo[p.career]?.name||'your field'}. They cannot guarantee the committee will select you.`,p=>[
 S('Submit a serious application','Invest time and expose your work to judgment.',{energy:-2,stress:1,recognition:1,skills:{[careerInfo[p.career]?.skill||'academics']:1}},'You put your work forward.',{special:'masteryBreakthrough'}),
 S('Nominate someone overlooked','Share opportunity rather than seeking the spotlight.',{bonds:2,purpose:2,recognition:-1},'You use the moment to make other work visible.'),
 S('Decline for now','Protect privacy and energy at the expense of a possible prize.',{energy:2,stress:-1,options:-1},'You do not participate in this round.')],'everyday','ambition'),
M(42,'Midlife','An ethical shortcut at work','A manager asks you to exaggerate a project’s success in a public report. The pressure is real.',[
 S('Refuse to distort the results','Act on your standards, risking retaliation.',{purpose:2,stress:2,options:-1},'You decline to make a claim the evidence cannot support.',{special:'ethicsOutcome'}),
 S('Suggest an accurate, qualified report','Look for a defensible solution with political costs.',{skills:{business:1},stress:1,options:1},'You present uncertainty rather than hiding it.',{special:'ethicsOutcome'}),
 S('Follow the manager’s instruction','Protect short-term position while compromising trust.',{cash:1000,recognition:1,purpose:-2,stress:2},'You gain short-term benefit but risk future accountability.',{later:{offset:7,delta:{cash:-2300,recognition:-2},text:'The inaccurate report prompts a difficult review.'}})],'major','ethics'),
M(43,'Midlife','Does your business still represent your goals?',p=>p.venture?`Your ${ventureNames[p.venture.kind]||'business'} may grow or remain small. It also occupies attention you could spend elsewhere.`:'You are considering whether to start a project later in life or invest in community organizations instead.',p=>[
 S('Hire or promote a team lead','Accept higher costs and shared control for sustainable work.',{cash:-1700,bonds:1,energy:2,stress:-1},'You build an organization rather than a one-person job.',{special:'venturePartner',when:p=>!!p.venture,lock:'Requires an active business'}),
 S('Pursue rapid growth','Accept significant expenses and uncertainty.',{cash:-3400,energy:-2,stress:2,recognition:1},'You try to scale beyond your current reach.',{special:'ventureScale',when:p=>!!p.venture,lock:'Requires an active business'}),
 S('Build a shared local project','Invest in a mission rather than chasing financial size.',{cash:-800,bonds:2,purpose:2,options:1},'You begin or contribute to a community project.',{set:{communityProject:true}})],'everyday','business'),
M(45,'Midlife','A business downturn',p=>p.venture?`A client cancels or operating expenses rise at ${ventureNames[p.venture.kind]||'your venture'}. Are you still willing to build it?`:'People in your field are facing uncertain budgets. You can help adapt or protect your position.',p=>[
 S('Adjust services and speak with clients','Respond to actual feedback, with costs and no guarantee.',{cash:-1000,energy:-2,stress:1,skills:{business:1}},'You adapt using new information.',{special:'ventureRecovery',when:p=>!!p.venture,lock:'Requires an active venture'}),
 S('Close or step back from the business','Avoid escalating losses, but give up a dream.',{energy:2,stress:-2,purpose:-1},'You decide to stop the venture without equating it to your worth.',{when:p=>!!p.venture,lock:'Requires an active venture',set:{closeVenture:true}}),
 S('Help a local firm or organization adjust','Learn collective problem-solving instead of taking direct financial risk.',{bonds:1,options:1,skills:{business:1}},'You share ideas without having to run a company.')],'major','business'),
M(46,'Midlife','What is a promotion worth?',p=>`Your experience in ${careerInfo[p.career]?.name||'work'} earns you an interview for greater responsibility. What would you sacrifice?`,[
 S('Take the promotion if offered','Seek more authority and income, with longer hours.',{energy:-2,stress:2,options:1},'You interview for greater responsibility.',{special:'recognition'}),
 S('Negotiate a different kind of role','Accept less immediate status for flexibility.',{bonds:1,energy:1,options:1,stress:-1},'You try to make the work sustainable.',{special:'socialRepair'}),
 S('Decline and mentor your team','Use experience to develop colleagues rather than status.',{bonds:2,purpose:2,recognition:-1},'You prioritize shared success.')],'major','career'),
M(48,'Midlife','A passion you left behind',p=>p.sport?`You once put real time into ${p.sport}. Your relationship to sport has changed.`:'A hobby you once loved resurfaces. You are not required to be excellent at it.',[
 S('Return as an amateur','Invest in enjoyment without professional pressure.',{cash:-500,energy:1,purpose:2,belonging:1},'You rediscover the activity as a source of meaning.'),
 S('Teach someone else','Pass on knowledge while sacrificing some free time.',{bonds:2,energy:-1,purpose:1,skills:{care:1}},'Your experience becomes valuable to someone else.'),
 S('Continue focusing elsewhere','Keep your present priorities, with occasional nostalgia.',{cash:300,options:1,purpose:-1},'You accept that life contains paths you will not follow.')],'everyday','interests'),
M(49,'Midlife','Does success feel the way you expected?',p=>`Your visible reputation is ${p.recognition}/10, but your most recent self-reported feeling was ${p.feelingsLog.length?p.feelingsLog[p.feelingsLog.length-1].feeling.toLowerCase():'not recorded'}. Outside observers may not know why you felt this way.`,[
 S('Write a private reflection','Consider experiences that external measurements overlook.',{purpose:2,stress:-1,energy:1},'You recognize gaps between outside status and first-person meaning.',{set:{reflectedOnSuccess:true}}),
 S('Ask a trusted person how they see you','Compare your self-image with another perspective.',{bonds:2,belonging:1,stress:1},'Your interpretations are not identical, but the exchange matters.'),
 S('Pursue the next visible milestone','Seek recognition, while risking a cycle of comparison.',{recognition:1,stress:2,energy:-1},'Your external story expands, regardless of how it feels.')],'everyday','reflection'),
M(51,'Midlife','What happens to the organization you built?',p=>p.venture?`Your venture in ${ventureNames[p.venture.kind]||'services'} has reached stage ${p.venture.stage}. Sustainability matters more than one dramatic success.`:'You have a chance to take responsibility for an existing organization, even without being its owner.',p=>[
 S('Train a successor or partner','Give others capability and reduce reliance on yourself.',{cash:-900,energy:2,bonds:2,purpose:2},'You build something that may outlast your direct involvement.',{special:'venturePartner',when:p=>!!p.venture,lock:'Requires an active venture'}),
 S('Expand into another community','Commit to risk, new hiring, and uncertain demand.',{cash:-2800,stress:2,energy:-2,recognition:1},'You attempt broader reach.',{special:'ventureScale',when:p=>!!p.venture,lock:'Requires an active venture'}),
 S('Lead a nonprofit or team project','Practice leadership without needing business ownership.',{bonds:2,purpose:2,energy:-1,skills:{business:1}},'You build collective agency in another setting.')],'everyday','business'),
M(52,'Midlife','Conflict after years together',p=>p.flags.partnered?'Your partner says the relationship has changed. Old assumptions no longer describe both of you.':'A sibling, close friend, or chosen-family member says an old agreement is not working anymore.',[
 S('Listen and renegotiate expectations','Make space for changing perspectives.',{bonds:2,belonging:2,energy:-2,stress:1},'The relationship adapts instead of pretending nothing changed.',{special:'socialRepair'}),
 S('Maintain the arrangement as it is','Preserve routine, but leave another person dissatisfied.',{energy:1,stress:1,bonds:-2},'The conflict remains unresolved.',{later:{offset:5,delta:{bonds:-1,stress:1},text:'An unaddressed relationship tension resurfaces.'}}),
 S('Set a different boundary','Accept possible distance in exchange for clarity.',{bonds:-1,purpose:2,stress:-1},'You create space without knowing how the relationship will develop.')],'major','emotions'),
M(54,'Midlife','A last push for the top',p=>`You have spent years developing skills. Recognition is ${p.recognition}/10 and your best practice area is ${Object.entries(p.skills).sort((a,b)=>b[1]-a[1])[0][0]}.`,[
 S('Apply for the top role or exhibition','Spend time preparing for a highly selective opportunity.',{energy:-3,stress:2,recognition:1},'You submit yourself to a selective evaluation.',{special:'masteryBreakthrough'}),
 S('Build a collaborative legacy','Share methods and knowledge through a group.',{bonds:2,purpose:2,skills:{care:1},energy:-1},'Your influence may become larger than your individual title.'),
 S('Redefine what mastery looks like','Protect wellbeing while continuing to practice.',{energy:2,purpose:2,stress:-2,recognition:-1},'You decide that competence and status are not identical.')],'major','ambition'),
M(55,'Later adulthood','An old mentor disappoints you','Someone you once admired makes a choice that conflicts with your values. You are unsure whether to confront them.',[
 S('Ask for their reasoning','Try to understand the choice without excusing it.',{stress:1,skills:{care:1},bonds:1},'You hear a perspective that does not erase your disagreement.',{special:'socialRepair'}),
 S('Set a boundary','Protect your principles while changing a valued relationship.',{purpose:2,bonds:-1,stress:-1},'You recognize that respect and agreement are different.'),
 S('Learn from the disappointment privately','Use the experience to reconsider your own standards.',{purpose:1,energy:1},'Your interpretation changes without a public confrontation.')],'everyday','emotions'),
M(57,'Later adulthood','Health and the time you have','A clinician recommends a routine check and more sustainable habits. Access and work schedules affect what people can do.',[
 S('Schedule care and adjust routines','Spend time and money on preventive attention.',{cash:-600,energy:2,stress:-1},'You follow up on health without any guaranteed outcome.'),
 S('Ask for practical help accessing care','Rely on relationships or public programs to reduce the burden.',{bonds:1,energy:1,options:1},'You work around an access barrier.'),
 S('Delay the appointment because of obligations','Keep this week flexible but leave uncertainty unresolved.',{cash:500,stress:2,energy:-1},'You delay care, not because of lower intelligence but competing conditions.')],'everyday','emotions'),
M(58,'Later adulthood','Friendships after the busiest years','Your social circle has changed through work, relocation and family obligations.',[
 S('Organize a regular gathering','Spend energy to rebuild connection.',{cash:-350,bonds:2,belonging:2,energy:-1},'You make friendship an intentional practice.'),
 S('Reconnect one-on-one','Choose depth over breadth.',{bonds:2,belonging:1,energy:-1},'One relationship becomes more present.'),
 S('Enjoy solitude and new hobbies','Invest in peace and curiosity, knowing others may see it differently.',{energy:2,purpose:1,belonging:-1},'Your life remains meaningful without a large social circle.')],'everyday','social'),
M(60,'Later adulthood','Who gets access to your expertise?',p=>`You have experience in ${careerInfo[p.career]?.name||'your field'}. Someone asks you to mentor a student who has fewer resources than you had at that age.`,[
 S('Mentor without charging','Share time and expertise directly.',{bonds:2,purpose:2,energy:-2},'You make knowledge easier to access.'),
 S('Create a small paid class','Share expertise and cover costs, while raising access questions.',{cash:950,skills:{business:1},energy:-2,options:1},'You build structured learning that not everyone can afford.'),
 S('Help design a free community resource','Work collectively to expand access.',{cash:-500,bonds:2,purpose:2,energy:-2},'Your knowledge becomes one part of shared infrastructure.')],'everyday','ethics'),
M(63,'Later adulthood','An award for your lifetime of work',p=>`Your reputation is ${p.recognition}/10, but the committee knows only some of your story.`,[
 S('Accept the nomination','Seek recognition with uncertain selection.',{stress:1,recognition:1,energy:-1},'You put your public work before a committee.',{special:'masteryBreakthrough'}),
 S('Recommend overlooked peers','Use attention to share recognition.',{bonds:2,purpose:2,recognition:-1},'You widen who gets seen.'),
 S('Decline public attention','Keep privacy and invest in personal meaning.',{purpose:1,stress:-1,energy:1},'Your value is not dependent on the award.')],'everyday','ambition'),
M(66,'Later adulthood','A difficult family boundary','A relative asks you to provide ongoing financial support you may not be able to sustain.',[
 S('Agree to limited predictable support','Help with clear boundaries and a defined budget.',{cash:-1300,bonds:1,stress:1,purpose:1},'Your help is real but not unlimited.'),
 S('Offer practical guidance instead','Preserve money but use time and care.',{bonds:1,energy:-1,options:1},'You contribute another kind of resource.'),
 S('Say no for now','Protect long-term security, accepting disappointment.',{cash:500,bonds:-1,stress:-1},'The relationship must navigate an uncomfortable limit.')],'major','emotions'),
M(68,'Later adulthood','A younger person challenges your beliefs','Someone younger argues that your generation misunderstood what success requires. You disagree but want to understand.',[
 S('Ask questions and revise what you can','Practice learning without surrendering judgment.',{skills:{academics:1},bonds:1,purpose:1},'Both people see where their perspectives overlap and differ.'),
 S('Explain your reasoning at length','Offer history and evidence, with the risk of talking past them.',{skills:{academics:1},stress:1},'You make your position clearer.'),
 S('Agree to disagree','Preserve energy, but leave some ideas unexamined.',{energy:1,bonds:-1},'The conversation ends without consensus.')],'everyday','reflection'),
M(70,'Later adulthood','A missed opportunity returns',p=>`Someone offers a new version of an opportunity you once passed up. Your current circumstances are different, even though the choice sounds familiar.`,[
 S('Try it now','Revisit an old goal with more experience and less certainty.',{cash:-750,energy:-1,purpose:2},'The same activity means something different at this age.',{special:'recognition'}),
 S('Help someone younger pursue it','Transform a personal regret into another person’s opportunity.',{bonds:2,purpose:2,energy:-1},'You support a path you did not take.'),
 S('Appreciate the path you chose','Protect a life you have built without reopening the old choice.',{energy:1,stress:-1,purpose:1},'You accept an unfinished possibility.')],'everyday','reflection'),
M(73,'Later adulthood','A letter to your younger self','You imagine your younger self looking at your career, relationships, and choices. What would you want them to understand?',[
 S('Skill mattered, but access mattered too','Acknowledge both preparation and institutional conditions.',{purpose:1,skills:{academics:1}},'You reject a one-variable explanation of success.'),
 S('Other people helped create this life','Recognize care, trust and shared opportunities.',{bonds:1,belonging:1,purpose:1},'Your identity is not solely individual.'),
 S('No outside record captures what it felt like','Honor the first-person dimension of experience.',{purpose:2,energy:1},'You keep subjective experience separate from a visible score.')],'reflection','reflection')
];
const ventureNames={sports:'Sports training and youth coaching',tech:'Web tools and IT services',community:'Community tutoring and education',creative:'Design and media studio',food:'Food service and catering',repairs:'Home repair services'};
scenes.push(...extraScenes);
scenes.sort((a,b)=>a.age-b.age);
const oldSceneMap=baseScenes.map(s=>scenes.indexOf(s));

const spinTurns=new Set([7,17,26,34,42,55,66,78,90]);
const spinEvents=[
{title:'An accessible public grant',text:'A local institution funds supplies or training.',delta:{cash:580,options:1}},
{title:'Unexpected transport problems',text:'Travel gets harder and costs more than expected.',delta:{cash:-540,energy:-1}},
{title:'A mentor opens a door',text:'Someone shares information about an overlooked opportunity.',delta:{options:1,bonds:1}},
{title:'A repair bill',text:'A necessary repair draws down cash.',delta:{cash:-700}},
{title:'Mutual aid',text:'People around you share help without a financial transaction.',delta:{bonds:1,energy:1}},
{title:'A schedule disruption',text:'An unexpected commitment interrupts your plans.',delta:{energy:-2}},
{title:'A short paid project',text:'A short-term job adds some cash while using time.',delta:{cash:900,energy:-1}},
{title:'A new program with limited space',text:'You find a competitive opportunity without a guaranteed place.',delta:{options:1,energy:-1}}
];
const chanceDeck={
child:{good:['A teacher sees your effort','A school employee offers useful guidance.',{options:1}],neutral:['A typical school week','Nothing extra changes this week.',{}],bad:['A cancelled activity','A schedule change costs you practice time.',{energy:-1}]},
sport:{good:['An encouraging performance','Your effort is noticed by a coach or teammate.',{skills:{sport:1},options:1}],neutral:['Training continues','Practice helps, but there is no extra breakthrough.',{}],bad:['A difficult training week','Conditions make practice harder than expected.',{energy:-2,skills:{sport:-1}}]},
recruit:{good:['A second evaluation','A coach offers another chance to demonstrate skills.',{options:1}],neutral:['No new recruitment contact','Your submissions are reviewed without another response.',{}],bad:['Travel funding falls short','A trip or tryout costs extra money.',{cash:-360,energy:-1}]},
education:{good:['Fee waiver or study grant','You receive targeted aid for a program.',{cash:1150,options:1}],neutral:['An ordinary study term','Your plan goes forward without an extra surprise.',{}],bad:['Course schedule changes','An added requirement consumes time and money.',{cash:-700,energy:-1}]},
career:{good:['A useful professional referral','A colleague helps you find a paid opening.',{cash:800,options:1}],neutral:['A normal work period','Your role continues without another unexpected development.',{}],bad:['Hours are cut','A shift or contract ends unexpectedly.',{cash:-850,energy:-1}]},
social:{good:['Someone reaches out','An old connection becomes helpful at the right time.',{bonds:1,energy:1}],neutral:['Social life continues','Relationships evolve without a sudden change.',{}],bad:['A misunderstanding spreads','A miscommunication makes a relationship harder.',{bonds:-1,energy:-1}]},
ethics:{good:['Unexpected support','Someone else speaks up in support of your position.',{bonds:1,options:1}],neutral:['An imperfect outcome','The issue remains complicated without sudden resolution.',{}],bad:['Institutional pushback','A decision-maker adds an obstacle to your efforts.',{cash:-650,energy:-1}]},
reflection:{good:['An unexpected reunion','Someone remembers a kindness from years ago.',{bonds:1}],neutral:['A quiet moment','You gain no new resource from reflecting.',{}],bad:['An emotional week','A difficult memory takes energy to revisit.',{energy:-1}]},
general:{good:['An unexpected opening','Someone shares a useful opportunity.',{options:1}],neutral:['Life moves forward','Nothing additional happens this time.',{}],bad:['A costly complication','An unexpected problem drains time or cash.',{cash:-350,energy:-1}]}
};

Object.assign(chanceDeck,{
 party:{good:['A good conversation','You meet someone whose perspective expands your own.',{bonds:1,belonging:1}],neutral:['An ordinary social night','You gain an experience without a large lasting effect.',{}],bad:['An exhausting morning','A late night disrupts your next commitment.',{energy:-1,stress:1}]},
 business:{good:['A referral from a customer','Someone recommends your work to a new person.',{cash:550,recognition:1}],neutral:['Slow progress','Your business or project continues without a breakthrough.',{}],bad:['Administrative overhead','A permit, fee or schedule delay consumes resources.',{cash:-550,stress:1}]},
 emotions:{good:['An unexpected understanding','A conversation helps someone understand how you saw an event.',{bonds:1,belonging:1}],neutral:['A complicated feeling','There is no dramatic external event, even though it feels important.',{}],bad:['A misunderstanding','Your intentions are interpreted differently than you expected.',{bonds:-1,stress:1}]},
 ambition:{good:['New recognition','Someone notices a skill you worked on.',{recognition:1,options:1}],neutral:['Incremental effort','Your work adds experience without public recognition.',{}],bad:['A competitive setback','Someone else receives a scarce opportunity.',{stress:1,recognition:-1}]}
});
const variantDeck={
 party:{good:[['An invitation to return','A friend wants to include you in another event.',{bonds:1,belonging:1}],['A new conversation','You hear a perspective you would not have encountered otherwise.',{options:1,purpose:1}]],bad:[['A deadline slips','A busy social schedule makes the next day more demanding.',{energy:-1,stress:1}],['You feel out of place','The crowd does not feel as welcoming as you expected.',{belonging:-1,stress:1}]]},
 emotions:{good:[['Someone checks in','A friend makes time to hear you.',{bonds:1,belonging:1}],['Quiet reassurance','A thoughtful exchange makes things feel more manageable.',{stress:-1}]],bad:[['A crossed signal','Another person reads your behavior differently than intended.',{bonds:-1}],['Social fatigue','You need additional time after a demanding interaction.',{energy:-1,stress:1}]]},
 business:{good:[['A repeat customer','Someone returns for your work.',{cash:450,recognition:1}],['An unexpected recommendation','An introduction produces a small opening.',{options:1}]],bad:[['Supplier cost increase','A routine cost rises without warning.',{cash:-420}],['Customer reschedules','Expected work shifts to another week.',{stress:1,cash:-350}]]}
};

function sceneNow(p){return scenes[game.round];}
function choicesFor(p){let raw=sceneNow(p).choices;return typeof raw==='function'?raw(p):raw;}
function record(p,title,text,kind='choice'){p.journal.push({age:scenes[game.round]?.age??75,step:game.round,title,text,kind});}
function skillChange(p,mod){for(const [k,v] of Object.entries(mod||{}))if(k in p.skills)p.skills[k]=clamp(p.skills[k]+v);}

function apply(p,delta={}){
  const tracked=['cash','debt','energy','bonds','options','stress','belonging','purpose','recognition'];
  const was=Object.fromEntries(tracked.map(k=>[k,Number(p[k]||0)]));
  const oldSkills={...p.skills};
  if(delta.repay){const paid=Math.max(0,Math.min(p.cash,p.debt,delta.repay));p.cash-=paid;p.debt-=paid;}
  if(typeof delta.cash==='number'){
    p.cash+=delta.cash;
    if(p.cash<0){const short=-p.cash;p.cash=0;if(scenes[game.round]?.age>=18)p.debt+=short;else p.options=clamp(p.options-1);}
  }
  if(typeof delta.debt==='number')p.debt=Math.max(0,p.debt+delta.debt);
  for(const k of ['energy','bonds','options','stress','belonging','purpose','recognition'])if(typeof delta[k]==='number')p[k]=clamp(Number(p[k]||0)+delta[k]);
  skillChange(p,delta.skills);
  let dif={};for(const k of tracked)if(was[k]!==p[k])dif[k]=p[k]-was[k];
  for(const [k,v] of Object.entries(p.skills))if(v!==oldSkills[k])dif['skill_'+k]=v-oldSkills[k];
  return dif;
}
function asText(delta){const o=Object.entries(delta||{});if(!o.length)return 'No additional tracked change';return o.map(([k,v])=>`${v>0?'+':''}${k==='cash'||k==='debt'?usd(v):v+' '+(k.startsWith('skill_')?k.slice(6)+' practice':k)}`).join(', ');}
function updateCareer(p,next,reason='Career decision'){
 const previous=p.career;
 if(previous===next)return;
 if(!Array.isArray(p.careerHistory))p.careerHistory=[];
 const age=scenes[game.round]?.age??75;
 if(previous==='athlete'&&next!=='athlete'){
   p.flags.pro=false;
   p.flags.proEndAge=age;
 }
 if(next==='athlete'){
   p.flags.pro=true;
   p.flags.everPro=true;
   if(p.flags.proStartAge==null)p.flags.proStartAge=age;
 }
 p.career=next;
 p.careerHistory.push({age,previous,next,reason});
}

function setVars(p,data={}){
 for(const [k,v] of Object.entries(data)){
  if(k==='sport'){p.sport=v;p.flags.playedSport=!!v;}
  else if(k==='career')updateCareer(p,v,'Player selected a new professional path');
  else if(k==='closeVenture'&&v){p.venture=null;p.flags.businessClosed=true;if(p.career==='founder')updateCareer(p,'freelance','Business closed; independent work begins');}
  else if(['route','major','program','interest'].includes(k))p[k]=v;
  else p.flags[k]=v;
 }
}

function odds(p,kind){
 let favorable=clamp(27+Math.round((p.options-5)*1.4+(p.bonds-5)*.5)-(p.background.friction-2)*2+(p.flags.mentor?3:0),13,46);
 let difficult=clamp(26+(p.energy<4?5:0)+(p.background.pressure-2)*1.3+(p.background.friction-2)*1.8-(p.bonds>7?2:0),16,46);
 if(kind==='emotions'||kind==='social'||kind==='party'){
   favorable=clamp(favorable+(p.belonging-5)*.7-(p.stress-5)*.8,10,50);
   difficult=clamp(difficult+(p.stress-5)*1.2-(p.belonging-5)*.5,12,55);
 }
 if(kind==='ambition'||kind==='business'){
   favorable=clamp(favorable+(p.skills.business-3)*.9+(p.recognition-4)*.55,9,52);
   difficult=clamp(difficult+(p.stress-5)*.9,11,53);
 }
 favorable=Math.round(favorable);difficult=Math.round(difficult);
 if(favorable+difficult>83)difficult=83-favorable;
 return {favorable,difficult,ordinary:100-favorable-difficult};
}
function specialResult(p,special){
 const roll=1+rng(100);let good=false,title='',text='',delta={};
 if(special==='recruitment'){
  const chance=clamp(11+p.skills.sport*6+p.skills.academics*1+(p.flags.showcase?6:0)+p.options*1.2-p.background.friction*3,9,78);
  good=roll<=chance;title=good?'A recruiter responds':'No recruitment offer this time';text=good?`A coach contacts you about ${p.sport}. This opens a possible route, not guaranteed funding.`:'Recruiters do not offer a spot this time. College and sports pathways remain possible through other routes.';delta=good?{options:2,bonds:1}:{energy:-1};if(good)p.flags.recruiterContact=true;
 }else if(special==='collegeAthletics'){
  const chance=clamp(15+p.skills.sport*5+p.skills.academics*1.1+(p.flags.recruiterContact?12:0)-p.background.friction*2,10,82);
  good=roll<=chance;title=good?'College athletics opportunity':'No varsity offer this time';
  text=good?`A college program offers a roster opportunity in ${p.sport}. In this game, some aid accompanies it.`:'A roster or athletics scholarship does not materialize. Club sport or future training remains possible.';
  delta=good?{cash:3600,options:2,energy:-1}:{energy:-1};if(good){p.flags.varsity=true;p.flags.athleticAid=true;if(p.route!=='college'){p.route='college';p.major='exercise';apply(p,{cash:-3300});text+=' You switch into a college sport-management track and pay transition costs.';}};
 }else if(special==='proTryout'){
  const chance=clamp(1+p.skills.sport*.8+(p.flags.varsity?3:0)+(p.flags.showcase?1:0)+(p.flags.recruiterContact?2:0)-(p.flags.injury?5:0)-p.background.friction*.5,1,14);
  good=roll<=chance;title=good?'Professional development contract':'No professional contract';
  text=good?`You earn a fictional developmental professional contract in ${p.sport}. Earnings and injury risk are now much higher.`:'This particular professional tryout does not result in a contract. Your training still supports sport-related and non-sport careers.';
  delta=good?{cash:4800,energy:-2,options:2}:{cash:-400,energy:-1};if(good)updateCareer(p,'athlete','Professional developmental tryout succeeded');
 }else if(special==='trainingRisk'){
  const risk=clamp(15+(p.energy<4?18:0)+p.background.pressure*2,8,47);
  good=roll>risk;title=good?'Training goes to plan':'Injury disrupts training';text=good?'You complete this period without a significant setback.':'A sports injury interrupts practice and limits your schedule. This does not reflect your ability or effort.';delta=good?{skills:{sport:1}}:{skills:{sport:-2},energy:-2,cash:-400};if(!good)p.flags.injury=true;
 }

 else if(special==='partyOutcome'||special==='adultPartyOutcome'||special==='excessDrinking'){
  const isExcess=special==='excessDrinking';
  const goodChance=isExcess?8:special==='adultPartyOutcome'?35:42;
  const badChance=isExcess?58:special==='adultPartyOutcome'?21:25;
  good=roll<=goodChance;
  if(good){title=isExcess?'A friend intervenes':'An unexpectedly meaningful night';text=isExcess?'A trusted friend encourages you to stop drinking and get home safely. You have support, but the risky choice was not harmless.':'You have an interesting conversation and feel closer to someone.';delta=isExcess?{bonds:1,stress:1}:{bonds:1,belonging:1};}
  else if(roll<=goodChance+badChance){title=isExcess?'A dangerous complication':'A social complication';text=isExcess?'The night involves an unsafe situation requiring sober assistance or medical evaluation. No impaired driving is involved.':'Your plans conflict, you miss a commitment, or you feel left out despite being present.';delta=isExcess?{cash:-900,energy:-3,stress:2}:{energy:-1,stress:1,belonging:-1};}
  else{title='No extra event';text='The gathering ends without a major new consequence. Your immediate costs and choices still matter.';delta={};}
 }else if(special==='socialRepair'){
  const chance=clamp(25+p.bonds*3+p.belonging*1.2-p.stress*1.8,12,75);
  good=roll<=chance;title=good?'A conversation opens a door':'Understanding takes more time';text=good?'The other person listens and shares a perspective you had not considered.':'The conversation remains unresolved, even though you took a thoughtful step.';
  delta=good?{bonds:1,belonging:1,stress:-1}:{stress:1};
 }else if(special==='recognition'||special==='masteryBreakthrough'){
  const mastery=special==='masteryBreakthrough';
  const key=(careerInfo[p.career]||careerInfo.service).skill;
  const skill=p.skills[key]||0;
  const chance=clamp((mastery?5:18)+skill*(mastery?2.6:4)+p.recognition*1.3+p.options*.8-p.stress*.6,mastery?3:10,mastery?43:71);
  good=roll<=chance;title=good?(mastery?'A rare career breakthrough':'Your work is recognized'):(mastery?'No elite award this time':'The request does not lead to recognition');
  text=good?'You receive a selective opportunity after years of work, networks, and uncertainty.':'Another candidate or idea is selected. The result is not a total measure of your skill or understanding.';
  delta=good?{cash:mastery?2500:1100,recognition:mastery?3:2,options:2,stress:1}:{energy:-1,stress:1};
  if(good&&mastery)p.flags.majorAchievement=true;
 }else if(special==='ethicsOutcome'){
  const chance=clamp(35+p.bonds*2+p.options*1.5-p.background.friction*3,17,75);
  good=roll<=chance;title=good?'Support for your position':'Institutional resistance';text=good?'Another person supports your insistence on honest evidence.':'You encounter pushback for questioning a powerful person. The choice still expresses your values.';
  delta=good?{bonds:1,options:1,recognition:1}:{options:-1,stress:2};
 }else if(special==='businessLaunch'){
  const kind=p.flags.ventureKind||'community';
  const key=({sports:'sport',tech:'tech',community:'care',creative:'art',food:'craft',repairs:'craft'})[kind]||'business';
  const chance=clamp(19+p.skills.business*3+p.skills[key]*3+(p.flags.validatedIdea?9:0)+(p.flags.prototype?5:0)+p.options*.9-p.stress*.7,12,74);
  good=roll<=chance;
  p.venture={kind,stage:good?1:0,customers:good?3:1,active:true,launchedAge:scenes[game.round].age};
  title=good?'A modest first launch':'A slow and difficult launch';
  text=good?'Your new venture secures a few early customers. That is not the same as profitability or long-term survival.':'The venture launches without enough demand to cover early costs. You can change course, seek support, or close later.';
  delta=good?{cash:1450,options:1,recognition:1,stress:1}:{cash:-950,stress:2,energy:-1};
  p.flags.everFounded=true;
 }else if(['ventureCustomers','ventureMarketing','venturePartner','ventureScale','ventureRecovery'].includes(special)){
  const v=p.venture;
  if(!v){title='No active venture';text='There is no business to update. Other work opportunities remain open.';delta={};}
  else{
   const base={ventureCustomers:36,ventureMarketing:28,venturePartner:39,ventureScale:16,ventureRecovery:32}[special];
   const chance=clamp(base+p.skills.business*3+v.stage*5+p.options*.8-p.stress*.9+(p.flags.validatedIdea?5:0),8,86);
   good=roll<=chance;
   if(good){v.stage=Math.min(5,v.stage+(special==='ventureScale'?2:1));v.customers+=special==='ventureScale'?12:3;title=special==='ventureScale'?'Growth succeeds this time':'The venture gains momentum';text=`Your ${ventureNames[v.kind]||'business'} wins customers or operational support, but ongoing work is still necessary.`;delta={cash:special==='ventureScale'?5200:2000,recognition:1,options:1,stress:1};}
   else if(roll>86){v.stage=Math.max(0,v.stage-1);v.customers=Math.max(0,v.customers-1);title='A material business setback';text='Costs, customers, or timing move against your plans. One setback does not determine your future.';delta={cash:-1650,stress:2,energy:-1};}
   else{title='Slow business progress';text='You invest time without a major breakthrough. Your skills and relationships still develop.';delta={cash:-300,stress:1};}
  }
 }
 const changes=apply(p,delta);return {kind:'special',roll,title,text,changes,good};
}

function chanceResult(p,scene,option,preOdds){
 if(option.special)return specialResult(p,option.special);
 const roll=1+rng(100);
 const band=roll<=preOdds.favorable?'good':roll<=preOdds.favorable+preOdds.ordinary?'neutral':'bad';
 const deck=chanceDeck[scene.kind]||chanceDeck.general;
 const possibles=variantDeck[scene.kind]?.[band]||[];
 const [title,text,delta]=possibles.length&&rng(100)<53?possibles[rng(possibles.length)]:deck[band];
 const changes=apply(p,delta);
 return {kind:'general',roll,title,text,changes,band,odds:preOdds};
}

function validSave(x){
 return x&&[5,6].includes(x.version)&&x.game&&['play','finish'].includes(x.game.screen)&&Array.isArray(x.game.players)&&x.game.players.length>=1&&x.game.players.length<=4&&Number.isInteger(x.game.round)&&x.game.round>=0&&x.game.round<=(x.version===5?baseScenes.length:scenes.length)&&Number.isInteger(x.game.current)&&x.game.current>=0&&x.game.current<x.game.players.length&&['decision','spin','result'].includes(x.game.phase)&&x.game.players.every(p=>typeof p.name==='string'&&p.name.length<100&&typeof p.cash==='number'&&typeof p.debt==='number'&&p.background&&typeof p.background.id==='string'&&Array.isArray(p.journal)&&Array.isArray(p.pending)&&p.skills&&p.flags&&typeof p.energy==='number');
}
function persist(){if(game.screen==='setup')return;try{localStorage.setItem(SAVE_KEY,JSON.stringify({version:6,game,prefs}));saveSupported=true;}catch(e){saveSupported=false;}}

function restore(saved){
 if(!validSave(saved))return false;
 // Migrate a V5 game to equivalent existing chapter in V6. Newly inserted earlier scenes are skipped.
 if(saved.version===5){
   const translate=i=>i>=baseScenes.length?scenes.length:(oldSceneMap[i]??scenes.length);
   const x=saved.game;
   x.round=translate(x.round);
   for(const p of x.players){
     p.visited=(p.visited||[]).map(translate);
     p.pending=(p.pending||[]).map(d=>({...d,due:translate(d.due)}));
     (p.journal||[]).forEach(j=>{if(Number.isInteger(j.step))j.step=translate(j.step)});
     (p.chanceHistory||[]).forEach(j=>{if(Number.isInteger(j.step))j.step=translate(j.step)});
   }
   saved.version=6;
 }
 game=saved.game;
 for(const p of game.players){
   if(!Array.isArray(p.careerHistory))p.careerHistory=[];
   if(!Array.isArray(p.feelingsLog))p.feelingsLog=[];
   if(!Array.isArray(p.visited))p.visited=[];
   if(p.flags.pro&&p.career==='athlete')p.flags.everPro=true;
   p.stress=Number.isFinite(p.stress)?clamp(p.stress):clamp(p.background.pressure+2);
   p.belonging=Number.isFinite(p.belonging)?clamp(p.belonging):clamp(p.bonds);
   p.purpose=Number.isFinite(p.purpose)?clamp(p.purpose):5;
   p.recognition=Number.isFinite(p.recognition)?clamp(p.recognition):2;
   if(!p.flags.lastIncomeAge&&p.visited.length){
     const agesSeen=p.visited.map(i=>scenes[i]?.age).filter(age=>age>=23);
     if(agesSeen.length)p.flags.lastIncomeAge=Math.max(...agesSeen);
   }
 }
 prefs=Array.isArray(saved.prefs)&&saved.prefs.length===game.players.length?saved.prefs:game.players.map(p=>({name:p.name,background:p.background.id,home:p.home.id,priority:p.priority}));
 return true;
}

function restoreAuto(){
 try{
  const newSave=localStorage.getItem(SAVE_KEY);
  if(newSave)return restore(JSON.parse(newSave));
  // Do not automatically import old games: a new V6 player should see the expanded childhood story.
  // Older V5 JSON backups are still supported through the Load Saved Game control.
  return false;
 }catch(e){saveSupported=false;return false;}
}
function clearSave(){try{localStorage.removeItem(SAVE_KEY);localStorage.removeItem(OLD_SAVE_KEY);}catch(e){saveSupported=false;}}
function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function saveFile(){download('beyond-the-score-v6-save.json',JSON.stringify({version:6,game,prefs},null,2),'application/json');}
async function importSave(file){try{const v=JSON.parse(await file.text());if(!restore(v)){alert('This is not a compatible Beyond the Score V5/V6 save file.');return;}render();}catch(e){alert('The save file could not be read.');}}
function readPrefs(){prefs=prefs.map((p,i)=>({name:document.getElementById('name'+i)?.value?.trim()||`Player ${i+1}`,background:document.getElementById('bg'+i)?.value||p.background,home:document.getElementById('home'+i)?.value||p.home,priority:document.getElementById('pr'+i)?.value||p.priority}));}
function start(){readPrefs();game={screen:'play',players:prefs.map((pr,i)=>{const b=backgrounds.find(x=>x.id===pr.background)||backgrounds[1],h=homes.find(x=>x.id===pr.home)||homes[0];return {id:i,name:pr.name,background:b,home:h,priority:pr.priority,cash:b.cash+h.cash,debt:0,energy:clamp(b.energy+h.energy),bonds:clamp(b.bonds+h.bonds),options:clamp(b.options+h.options),skills:{academics:1,sport:0,tech:0,art:0,care:0,business:0,craft:0},sport:null,interest:null,route:null,major:null,program:null,career:null,careerHistory:[],flags:{},pending:[],journal:[],chanceHistory:[],visited:[],feelingsLog:[],stress:clamp(b.pressure+1+h.pressure),belonging:clamp(b.bonds+h.bonds),purpose:5,recognition:2,venture:null};}),round:0,current:0,phase:'decision',arrivals:[],last:null,turnNote:'',chance:null};enter();render();}
function enter(){const p=game.players[game.current];game.arrivals=[];game.last=null;game.chance=null;game.turnNote=game.players.length>1?`Pass the device to ${p.name} for this chapter.`:'';
const sc=sceneNow(p);if(!p.visited.includes(game.round)){
 p.visited.push(game.round);
 if(sc.age>=38&&p.career==='athlete'){updateCareer(p,'trainer','Professional competition ends and a coaching/training career begins');game.arrivals.push({title:'A second career after competitive sport',text:'Your professional sports contract has ended. You enter a coaching and training track, with a different income and workload. Your earlier professional contract remains in your history.',changes:{}});record(p,'Athletic career transition','Competitive sports contract ended; coaching and training begin.','career');}if(sc.age>=23&&p.career&&p.flags.lastIncomeAge!==sc.age){
  p.flags.lastIncomeAge=sc.age;
  const base=(careerInfo[p.career]||careerInfo.service).pay;
  const mode=p.flags.workMode||'full-time';
  const gross=p.flags.retired?0:mode==='part-time'?Math.round(base*.45):mode==='consulting'?Math.round(base*.30):base;
  const costs=2050;
  const net=gross-costs;
  const changes=apply(p,{cash:net});
  const workLabel=p.flags.retired?'Retired':mode==='part-time'?'Part-time work':mode==='consulting'?'Occasional consulting':'Employment';
  game.arrivals.push({title:p.flags.retired?'Retirement living costs':'Simulated work income',text:`${workLabel} · ${careerInfo[p.career]?.name||'Work'}: ${usd(gross)} fictional periodic earnings minus ${usd(costs)} baseline living costs, net ${usd(net)}. This is not an annual salary.`,changes});
  record(p,'Work and living costs',`${workLabel}: fictional period net ${usd(net)}.`,'income');
 }
 if(sc.age>=23&&p.venture&&p.venture.active&&p.flags.lastVentureAge!==sc.age){
  p.flags.lastVentureAge=sc.age;
  const v=p.venture;
  const operatingNet=[-700,200,750,1450,2650,3900][Math.min(5,Math.max(0,v.stage||0))];
  const seasonal=rng(3)-1;
  const net=operatingNet+seasonal*350;
  const changes=apply(p,{cash:net,stress:net<0?1:0});
  game.arrivals.push({title:'Small business operating snapshot',text:`${ventureNames[v.kind]||'Your venture'}: fictional net ${usd(net)} for this stage, after simplified operating costs. Demand is uncertain.`,changes});
  record(p,'Business operations',`${ventureNames[v.kind]} net ${usd(net)} in a fictional operating snapshot.`,'business');
 }
 const due=p.pending.filter(x=>x.due===game.round);p.pending=p.pending.filter(x=>x.due!==game.round);
 for(const item of due){const happened=rng(100)<65;const changes=happened?apply(p,item.delta):{};const txt=happened?item.text:`A possible result did not occur: ${item.text}`;game.arrivals.push({title:happened?'Delayed consequence':'Possibility did not unfold',text:txt,changes});record(p,'Earlier decision returns',`${txt} (${asText(changes)})`,'delayed');}
 }
 game.phase=spinTurns.has(game.round)?'spin':'decision';
}
function spin(){if(game.phase!=='spin')return;const p=game.players[game.current];const roll=1+rng(8),event=spinEvents[roll-1];const changes=apply(p,event.delta);game.chance={roll,...event,changes};record(p,'World event: '+event.title,event.text+' ('+asText(changes)+')','world');game.phase='decision';render();scrollScene();}
function choose(index){if(game.phase!=='decision')return;const p=game.players[game.current],sc=sceneNow(p),options=choicesFor(p),opt=options[index];if(!opt||(opt.when&&!opt.when(p)))return;
 const pre=odds(p,sc.kind),changes=apply(p,opt.delta);
 
 if(opt.delta?.skills2)skillChange(p,opt.delta.skills2);
 if(opt.set)setVars(p,opt.set);
 if(opt.later)p.pending.push({due:Math.min(scenes.length-1,game.round+opt.later.offset),text:opt.later.text,delta:opt.later.delta});
 const chance=chanceResult(p,sc,opt,pre);p.chanceHistory.push({step:game.round,age:sc.age,...chance});
 game.last={label:opt.label,outcome:opt.outcome,changes,chance,delayed:!!opt.later};
 record(p,sc.title,opt.label+' — '+opt.outcome+' ('+asText(changes)+')');record(p,'Chance: '+chance.title,`Roll ${chance.roll}/100. ${chance.text} (${asText(chance.changes)})`,'chance');
 game.phase='result';render();scrollScene();
}
function advance(){if(game.phase!=='result')return;if(game.current+1<game.players.length)game.current++;else{game.current=0;game.round++;}if(game.round>=scenes.length)game.screen='finish';else enter();render();window.scrollTo({top:0,behavior:'instant'});}
function scrollScene(){if(window.innerWidth<1100)document.getElementById('scene')?.scrollIntoView({block:'start',behavior:'instant'});}



// Server bridge. Source data and chance mechanics are shared with the offline Expanded Edition.
function readPrefs(){} // The server provides each user's saved lobby profile.
function render(){} // No server-side DOM.
function scrollScene(){}
const clone=x=>JSON.parse(JSON.stringify(x));
globalThis.EngineBridge={
 list:()=>({backgrounds:clone(backgrounds),homes:clone(homes),priorities:clone(priorities),sportNames:clone(sportNames),total:scenes.length,steps:scenes.map((s,i)=>({index:i,age:s.age,stage:s.stage,title:s.title,type:s.type}))}),
 setup:(users)=>{prefs=clone(users);start();},
 state:()=>clone(game),
 chapter:()=>{if(game.screen==='finish')return null;const p=game.players[game.current],sc=sceneNow(p);return clone({age:sc.age,stage:sc.stage,title:sc.title,text:typeof sc.text==='function'?sc.text(p):sc.text,type:sc.type,kind:sc.kind,options:choicesFor(p).map((o,i)=>({index:i,label:o.label,desc:o.desc,enabled:!o.when||Boolean(o.when(p))}))});},
 turn:(type,value)=>{if(type==='choose')choose(value);else if(type==='spin')spin();else if(type==='next')advance();else if(type==='feeling'){if(game.phase!=='result'||!['Hopeful','Anxious','Conflicted','Relieved','Proud','Regretful','Lonely','Grateful','Frustrated','Uncertain','Excited','Overwhelmed'].includes(value))return;const p=game.players[game.current];const prev=p.feelingsLog.find(x=>x.step===game.round);if(prev)prev.feeling=value;else p.feelingsLog.push({step:game.round,age:scenes[game.round].age,feeling:value,scene:scenes[game.round].title});record(p,'Self-reported experience',value,'feeling');}else throw new Error('Unsupported move');},
 restore:(payload)=>restore(payload),
};
