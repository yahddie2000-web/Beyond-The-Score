from pathlib import Path
src=Path(__file__).with_name('offline-original.html').read_text()
from bs4 import BeautifulSoup
scripts=BeautifulSoup(src, 'html.parser').find_all('script')
text=scripts[-1].text
start=text.index('const app=')
end=text.index('const refs=')
core=text[start:end]
bridge='''
// Server bridge. Source data and chance mechanics are shared with the offline Expanded Edition.
function readPrefs(){} // The server provides each user's saved lobby profile.
function render(){} // No server-side DOM.
function scrollScene(){}
const clone=x=>JSON.parse(JSON.stringify(x));
globalThis.EngineBridge={
 list:()=>({backgrounds:clone(backgrounds),homes:clone(homes),priorities:clone(priorities),sportNames:clone(sportNames),total:scenes.length,steps:scenes.map((s,i)=>({index:i,age:s.age,stage:s.stage,title:s.title,type:s.type}))}),
 setup:(users)=>{prefs=clone(users);start();},
 state:()=>clone(game),
 chapter:()=>{if(game.screen==='finish')return null;const p=game.players[game.current],sc=sceneNow(p);return clone({age:sc.age,stage:sc.stage,title:sc.title,text:typeof sc.text==='function'?sc.text(p):sc.text,type:sc.type,kind:sc.kind,options:choicesFor(p).map((o,i)=>({index:i,label:o.label,desc:o.desc,enabled:!o.when||Boolean(o.when(p))}))});},
 turn:(type,value)=>{if(type==='choose')choose(value);else if(type==='spin')spin();else if(type==='next')advance();else if(type==='feeling'){if(game.phase!=='result'||!['Hopeful','Anxious','Conflicted','Relieved','Proud','Regretful','Lonely','Grateful','Frustrated','Uncertain','Excited','Overwhelmed'].includes(value))return;const p=game.players[game.current];const prev=p.feelingsLog.find(x=>x.step===game.round);if(prev)prev.feeling=value;else p.feelingsLog.push({step:game.round,age:scenes[game.round].age,feeling:value,scene:scenes[game.round].title});record(p,'Self-reported experience',value,'feeling');}else throw new Error('Unsupported move');},
 restore:(payload)=>restore(payload),
};
'''
Path(__file__).with_name('engine-core.js').write_text('/* Derived from Beyond the Score Expanded Life Edition. Shared by same-room online multiplayer. */\n'+core+bridge)
print('core generated',len(core),'chapters')
